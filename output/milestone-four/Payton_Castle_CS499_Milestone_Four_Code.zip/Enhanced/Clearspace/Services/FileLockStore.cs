using System.Security.Cryptography;

namespace Clearspace.Services;

internal sealed class FileLockStore(string databasePath, string? legacyPath = null) : IDisposable
{
    private readonly TagDatabase _database = new(databasePath, legacyPath);
    internal bool HasPassword => _database.Run(false, sql => sql.Number("SELECT COUNT(*) FROM LockSettings") != 0).Value;

    internal void CheckOrCreatePassword(ReadOnlySpan<char> password)
    {
        if (password.Length is < 12 or > 1024)
            throw new ArgumentException("Use a master password between 12 and 1,024 characters.");
        var settings = _database.Run(false, sql => sql.Query("SELECT Salt, Verifier FROM LockSettings WHERE Id = 1",
            r => (Salt: (byte[])r[0], Verifier: (byte[])r[1]))).Value.SingleOrDefault();
        var salt = settings.Salt ?? RandomNumberGenerator.GetBytes(32);
        var key = FileLockFormat.Derive(password, salt);
        byte[]? verifier = null;
        try
        {
            verifier = HMACSHA256.HashData(key, "Clearspace master password verifier v1"u8);
            if (settings.Salt is not null)
            {
                if (!CryptographicOperations.FixedTimeEquals(verifier, settings.Verifier))
                    throw new CryptographicException("The master password is incorrect.");
                return;
            }
            _database.Run(true, sql => sql.Execute("INSERT INTO LockSettings(Id,Salt,Iterations,Verifier) VALUES(1,$p0,$p1,$p2)",
                salt, FileLockFormat.Iterations, verifier));
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            if (verifier is not null) CryptographicOperations.ZeroMemory(verifier);
        }
    }

    internal void Record(string path, byte[] header, string state) => _database.Run(true, sql => sql.Execute("""
        INSERT INTO LockedFiles(FilePath,FileId,Header,State,UpdatedUtc) VALUES($p0,$p1,$p2,$p3,$p4)
        ON CONFLICT(FilePath) DO UPDATE SET FileId=excluded.FileId,Header=excluded.Header,State=excluded.State,UpdatedUtc=excluded.UpdatedUtc
        """, path, new Guid(header.AsSpan(8, 16)).ToString("N"), header, state, DateTime.UtcNow.ToString("O")));

    internal void Forget(string path) => _database.Run(true, sql => sql.Execute("DELETE FROM LockedFiles WHERE FilePath=$p0", path));
    internal string? State(string path) => _database.Run(false, sql => sql.Query("SELECT State FROM LockedFiles WHERE FilePath=$p0", r => r.GetString(0), path)).Value.SingleOrDefault();
    public void Dispose() => _database.Dispose();
}
