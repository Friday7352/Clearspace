using System.Buffers.Binary;
using System.IO;
using System.Security.Cryptography;

namespace Clearspace.Services;

// Version 1: fixed authenticated header followed by a single AES-GCM message.
// Size is bounded so unauthenticated files cannot request unbounded allocations or KDF work.
internal static class FileLockFormat
{
    internal const int HeaderSize = 156;
    internal const int MaxFileSize = 64 * 1024 * 1024;
    internal const int Iterations = 600_000;
    internal static ReadOnlySpan<byte> Magic => "CSLOCK01"u8;

    internal static byte[] Derive(ReadOnlySpan<char> password, ReadOnlySpan<byte> salt)
        => Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);

    internal static (byte[] Header, byte[] Ciphertext) Encrypt(byte[] plaintext, ReadOnlySpan<char> password)
    {
        if (plaintext.Length > MaxFileSize) throw new IOException("File locking supports files up to 64 MB.");
        var header = new byte[HeaderSize];
        Magic.CopyTo(header);
        Guid.NewGuid().TryWriteBytes(header.AsSpan(8, 16));
        BinaryPrimitives.WriteInt32LittleEndian(header.AsSpan(24, 4), Iterations);
        BinaryPrimitives.WriteInt64LittleEndian(header.AsSpan(28, 8), plaintext.LongLength);
        RandomNumberGenerator.Fill(header.AsSpan(36, 32)); // password salt
        RandomNumberGenerator.Fill(header.AsSpan(68, 12)); // wrapping nonce
        RandomNumberGenerator.Fill(header.AsSpan(128, 12)); // content nonce, independent key
        var dek = RandomNumberGenerator.GetBytes(32);
        var kek = Derive(password, header.AsSpan(36, 32));
        try
        {
            using (var wrapper = new AesGcm(kek, 16))
                wrapper.Encrypt(header.AsSpan(68, 12), dek, header.AsSpan(80, 32), header.AsSpan(112, 16), header.AsSpan(0, 68));
            var ciphertext = new byte[plaintext.Length];
            using var cipher = new AesGcm(dek, 16);
            cipher.Encrypt(header.AsSpan(128, 12), plaintext, ciphertext, header.AsSpan(140, 16), header.AsSpan(0, 140));
            return (header, ciphertext);
        }
        finally { CryptographicOperations.ZeroMemory(dek); CryptographicOperations.ZeroMemory(kek); }
    }

    internal static int Validate(byte[] header, long totalLength)
    {
        if (header.Length != HeaderSize || !header.AsSpan(0, 8).SequenceEqual(Magic))
            throw new InvalidDataException("This is not a supported Clearspace locked file.");
        var length = BinaryPrimitives.ReadInt64LittleEndian(header.AsSpan(28, 8));
        if (BinaryPrimitives.ReadInt32LittleEndian(header.AsSpan(24, 4)) != Iterations ||
            length < 0 || length > MaxFileSize || totalLength != HeaderSize + length)
            throw new InvalidDataException("The locked file is incomplete, damaged, or uses an unsupported format.");
        return (int)length;
    }

    internal static byte[] Decrypt(byte[] header, byte[] ciphertext, ReadOnlySpan<char> password)
    {
        Validate(header, HeaderSize + ciphertext.LongLength);
        var kek = Derive(password, header.AsSpan(36, 32));
        var dek = new byte[32];
        var plaintext = new byte[ciphertext.Length];
        try
        {
            using (var wrapper = new AesGcm(kek, 16))
                wrapper.Decrypt(header.AsSpan(68, 12), header.AsSpan(80, 32), header.AsSpan(112, 16), dek, header.AsSpan(0, 68));
            using var cipher = new AesGcm(dek, 16);
            cipher.Decrypt(header.AsSpan(128, 12), ciphertext, header.AsSpan(140, 16), plaintext, header.AsSpan(0, 140));
            return plaintext;
        }
        catch (CryptographicException)
        {
            CryptographicOperations.ZeroMemory(plaintext);
            throw new CryptographicException("The password is incorrect or the locked file has been changed. The file was not unlocked.");
        }
        finally { CryptographicOperations.ZeroMemory(dek); CryptographicOperations.ZeroMemory(kek); }
    }
}
