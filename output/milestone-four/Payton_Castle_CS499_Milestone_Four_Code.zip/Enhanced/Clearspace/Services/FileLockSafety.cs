using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;

namespace Clearspace.Services;

internal static class FileLockSafety
{
    internal static string ValidatePath(string path)
    {
        path = Path.GetFullPath(path);
        var root = Path.GetPathRoot(path)!;
        if (root.Length != 3 || root[1] != ':' || path.AsSpan(2).Contains(':'))
            throw new IOException("Choose a file on a local NTFS drive.");
        var drive = new DriveInfo(root);
        if (drive.DriveType is not (DriveType.Fixed or DriveType.Removable) || drive.DriveFormat != "NTFS")
            throw new IOException("File locking currently supports local NTFS drives.");
        for (var parent = Path.GetDirectoryName(path); parent is not null; parent = Path.GetDirectoryName(parent))
            if ((File.GetAttributes(parent) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Files inside linked or cloud placeholder folders cannot be locked yet.");
        var attributes = File.GetAttributes(path);
        if ((attributes & (FileAttributes.Directory | FileAttributes.ReparsePoint | FileAttributes.ReadOnly |
            FileAttributes.Encrypted | FileAttributes.Offline)) != 0)
            throw new IOException("Choose a writable local file that is not a link, cloud placeholder, or already Windows-encrypted.");
        return path;
    }

    internal static FileIdentity Identity(FileStream file)
    {
        if (!GetFileInformationByHandle(file.SafeFileHandle, out var info)) throw new Win32Exception();
        if (info.Links != 1) throw new IOException("Files with hard links cannot be locked because another name could retain readable contents.");
        if ((info.Attributes & (uint)FileAttributes.ReparsePoint) != 0) throw new IOException("Linked files cannot be locked.");
        return info;
    }

    internal static void CheckStreams(string path)
    {
        var handle = FindFirstStreamW(path, 0, out var data, 0);
        if (handle == new IntPtr(-1))
        {
            var error = Marshal.GetLastWin32Error();
            if (error == 38) return; // no streams on an empty file
            throw new Win32Exception(error);
        }
        try
        {
            do
            {
                if (data.Name != "::$DATA")
                    throw new IOException("This file has additional data streams. File locking currently supports files with one data stream.");
            } while (FindNextStreamW(handle, out data));
            if (Marshal.GetLastWin32Error() != 38) throw new Win32Exception();
        }
        finally { FindClose(handle); }
    }

    internal static FileStream CreatePrivateTemporary(string path)
    {
        var security = new FileSecurity();
        security.SetAccessRuleProtection(true, false);
        security.AddAccessRule(new FileSystemAccessRule(WindowsIdentity.GetCurrent().User!, FileSystemRights.FullControl, AccessControlType.Allow));
        security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), FileSystemRights.FullControl, AccessControlType.Allow));
        return new FileInfo(path).Create(FileMode.CreateNew, FileSystemRights.FullControl, FileShare.None,
            65536, FileOptions.WriteThrough, security);
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct FileIdentity
    {
        internal uint Attributes;
        internal System.Runtime.InteropServices.ComTypes.FILETIME Creation, Access, Write;
        internal uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
        internal readonly bool SameFile(FileIdentity other) => Volume == other.Volume && IndexHigh == other.IndexHigh && IndexLow == other.IndexLow;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct StreamData
    {
        internal long Size;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 296)] internal string Name;
    }
    [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetFileInformationByHandle(SafeFileHandle handle, out FileIdentity info);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr FindFirstStreamW(string name, int level, out StreamData data, uint flags);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool FindNextStreamW(IntPtr handle, out StreamData data);
    [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool FindClose(IntPtr handle);
}
