using System.IO;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;

namespace Clearspace.Services;

internal sealed record FileLockResult(bool Locked, string? Warning = null);

internal sealed class FileLockService(string databasePath, string? legacyPath = null)
{
    // A test seam at durable boundaries, also used to verify interruption recovery.
    internal Action<string>? Checkpoint { get; init; }
    internal bool HasPassword { get { using var store = new FileLockStore(databasePath, legacyPath); return store.HasPassword; } }

    internal static bool IsLocked(string path)
    {
        using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        Span<byte> magic = stackalloc byte[8];
        return file.Read(magic) == 8 && magic.SequenceEqual(FileLockFormat.Magic);
    }

    internal FileLockResult Transform(string path, char[] password, bool locking, CancellationToken token = default)
    {
        token.ThrowIfCancellationRequested();
        path = FileLockSafety.ValidatePath(path);
        // Deny writers throughout preparation; allow replacement of this file's directory entry.
        using var source = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete);
        var identity = FileLockSafety.Identity(source);
        FileLockSafety.CheckStreams(path);
        if (source.Length > FileLockFormat.MaxFileSize + (locking ? 0 : FileLockFormat.HeaderSize))
            throw new IOException("File locking supports files up to 64 MB.");
        var timestamp = File.GetLastWriteTimeUtc(path);
        var attributes = File.GetAttributes(path);
        var input = new byte[checked((int)source.Length)];
        byte[]? plaintext = null;
        byte[]? output = null;
        var temporary = Path.Combine(Path.GetDirectoryName(path)!, ".clearspace-lock-" + Guid.NewGuid().ToString("N") + ".tmp");
        using var store = new FileLockStore(databasePath, legacyPath);
        try
        {
            source.ReadExactly(input);
            byte[] header;
            if (locking)
            {
                if (input.AsSpan().StartsWith(FileLockFormat.Magic)) throw new IOException("This file is already locked. Choose Unlock file.");
                store.CheckOrCreatePassword(password);
                plaintext = input;
                var encrypted = FileLockFormat.Encrypt(plaintext, password);
                header = encrypted.Header;
                output = new byte[header.Length + encrypted.Ciphertext.Length];
                header.CopyTo(output, 0);
                encrypted.Ciphertext.CopyTo(output, header.Length);
            }
            else
            {
                if (input.Length < FileLockFormat.HeaderSize) throw new InvalidDataException("This is not a complete Clearspace locked file.");
                header = input[..FileLockFormat.HeaderSize];
                FileLockFormat.Validate(header, input.LongLength);
                plaintext = FileLockFormat.Decrypt(header, input[FileLockFormat.HeaderSize..], password);
                output = plaintext;
            }

            token.ThrowIfCancellationRequested();
            // Commit recovery metadata BEFORE replacing the file. The authenticated header also
            // travels with the file, so stale/missing database rows never make it undecryptable.
            store.Record(path, header, locking ? "Preparing" : "Unlocking");
            Checkpoint?.Invoke("Recorded");
            using (var destination = FileLockSafety.CreatePrivateTemporary(temporary))
            {
                destination.Write(output);
                destination.Flush(flushToDisk: true);
            }
            using (var check = File.OpenRead(temporary))
            {
                if (!CryptographicOperations.FixedTimeEquals(SHA256.HashData(check), SHA256.HashData(output)))
                    throw new IOException("The prepared file failed verification. The original file was kept.");
            }
            File.SetLastWriteTimeUtc(temporary, timestamp);
            File.SetAttributes(temporary, attributes);
            Checkpoint?.Invoke("Prepared");
            token.ThrowIfCancellationRequested();
            // Refuse a moved/replaced target; the open source handle also prevents concurrent writes.
            using (var current = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                if (!identity.SameFile(FileLockSafety.Identity(current)))
                    throw new IOException("The file moved or changed during preparation. Please try again.");
            FileLockSafety.ValidatePath(path);
            FileLockSafety.CheckStreams(path);
            File.Replace(temporary, path, null, ignoreMetadataErrors: false);
            Checkpoint?.Invoke("Replaced");
            // Replacement is the commit point. A bookkeeping failure must not be reported as an
            // encryption failure or prompt the user to repeat a destructive operation.
            try
            {
                if (locking) store.Record(path, header, "Locked");
                else store.Forget(path);
                return new FileLockResult(locking);
            }
            catch (Exception e) when (e is SqliteException or IOException)
            {
                return new FileLockResult(locking, "The file was " + (locking ? "locked" : "unlocked") +
                    ", but its database status could not be updated. Its contents remain recoverable with the password.");
            }
        }
        finally
        {
            CryptographicOperations.ZeroMemory(input);
            if (plaintext is not null) CryptographicOperations.ZeroMemory(plaintext);
            // Delete only the randomly named temporary file created by this operation.
            try { if (File.Exists(temporary)) File.Delete(temporary); } catch (IOException) { } catch (UnauthorizedAccessException) { }
        }
    }
}
