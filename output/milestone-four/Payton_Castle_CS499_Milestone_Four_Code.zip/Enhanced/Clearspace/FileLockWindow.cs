using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Clearspace.Services;

namespace Clearspace;

internal sealed class FileLockWindow : Window
{
    private readonly PasswordBox _password = new() { Padding = new Thickness(8), MaxLength = 1024 };
    private readonly PasswordBox _confirmation = new() { Padding = new Thickness(8), MaxLength = 1024 };
    private readonly TextBlock _status = new() { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 14, 0, 0) };
    private readonly Button _submit = new() { MinWidth = 110, Padding = new Thickness(16, 8, 16, 8), IsDefault = true };
    private readonly Button _cancel = new() { Content = "Cancel", MinWidth = 85, Padding = new Thickness(12, 8, 12, 8), Margin = new Thickness(0, 0, 8, 0) };
    private readonly CancellationTokenSource _cancellation = new();
    private readonly FileLockService _service;
    private readonly string _path;
    private readonly bool _locking, _setup;
    private bool _working;
    internal string? ResultMessage { get; private set; }

    internal FileLockWindow(string path, bool locking, FileLockService service)
    {
        _path = path; _locking = locking; _service = service;
        _setup = locking && !service.HasPassword;
        Title = locking ? "Lock file" : "Unlock file";
        Width = 500; SizeToContent = SizeToContent.Height;
        ResizeMode = ResizeMode.NoResize; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = new SolidColorBrush(Color.FromRgb(35, 34, 32));
        Foreground = new SolidColorBrush(Color.FromRgb(236, 233, 227));
        FontFamily = new FontFamily("Segoe UI"); FontSize = 14;
        var panel = new StackPanel { Margin = new Thickness(24) };
        panel.Children.Add(new TextBlock { Text = Title, FontSize = 24, FontWeight = FontWeights.SemiBold });
        panel.Children.Add(new TextBlock { Text = Path.GetFileName(path), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 16) });
        panel.Children.Add(new TextBlock
        {
            Text = locking
                ? "Locking encrypts this file in place. Keep your password safe: a forgotten password cannot be recovered. Existing copies and backups stay readable."
                : "Enter the password used to lock this file. Unlocking restores its readable contents in the same location.",
            TextWrapping = TextWrapping.Wrap
        });
        if (locking)
            panel.Children.Add(new TextBlock { Text = "One local file up to 64 MB. Folders and linked or cloud placeholder files are not supported yet.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 10, 0, 0) });
        panel.Children.Add(new TextBlock { Text = _setup ? "Create a master password (at least 12 characters)" : "Password", Margin = new Thickness(0, 18, 0, 6) });
        panel.Children.Add(_password);
        if (_setup)
        {
            panel.Children.Add(new TextBlock { Text = "Confirm password", Margin = new Thickness(0, 12, 0, 6) });
            panel.Children.Add(_confirmation);
        }
        panel.Children.Add(_status);
        var actions = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 20, 0, 0) };
        _submit.Content = locking ? "Lock file" : "Unlock file";
        actions.Children.Add(_cancel); actions.Children.Add(_submit); panel.Children.Add(actions);
        Content = panel;
        _submit.Click += Submit;
        _cancel.Click += (_, _) => { if (_working) { _cancellation.Cancel(); _status.Text = "Cancelling…"; } else Close(); };
        Closing += (_, e) => { if (_working) { e.Cancel = true; _cancellation.Cancel(); _status.Text = "Finishing safely before closing…"; } };
        Closed += (_, _) => { _password.Clear(); _confirmation.Clear(); _cancellation.Dispose(); };
        Loaded += (_, _) => _password.Focus();
    }

    private static char[] ReadPassword(PasswordBox box)
    {
        using var secret = box.SecurePassword;
        var memory = Marshal.SecureStringToGlobalAllocUnicode(secret);
        try { var chars = new char[secret.Length]; Marshal.Copy(memory, chars, 0, chars.Length); return chars; }
        finally { Marshal.ZeroFreeGlobalAllocUnicode(memory); }
    }

    private async void Submit(object sender, RoutedEventArgs e)
    {
        if (_working) return;
        var password = ReadPassword(_password);
        var confirmation = ReadPassword(_confirmation);
        try
        {
            if (password.Length == 0) { _status.Text = "Enter your password."; return; }
            if (_setup && !password.AsSpan().SequenceEqual(confirmation)) { _status.Text = "The passwords do not match."; return; }
            _working = true;
            _submit.IsEnabled = _password.IsEnabled = _confirmation.IsEnabled = false;
            _password.Clear(); _confirmation.Clear();
            _status.Text = _locking ? "Encrypting and verifying the file…" : "Checking the password and restoring the file…";
            var result = await Task.Run(() => _service.Transform(_path, password, _locking, _cancellation.Token));
            ResultMessage = result.Warning ?? (_locking ? "File locked. Use Unlock file to open it again." : "File unlocked.");
            _working = false;
            DialogResult = true;
        }
        catch (OperationCanceledException) { _working = false; Close(); }
        catch (Exception exception)
        {
            _status.Text = exception.Message;
        }
        finally
        {
            password.AsSpan().Clear(); confirmation.AsSpan().Clear();
            _working = false;
            _submit.IsEnabled = _password.IsEnabled = _confirmation.IsEnabled = true;
        }
    }
}
