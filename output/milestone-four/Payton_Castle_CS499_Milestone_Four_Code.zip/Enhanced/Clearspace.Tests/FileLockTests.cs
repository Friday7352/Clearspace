using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Clearspace.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Clearspace.Tests;

[TestClass]
public sealed class FileLockTests
{
    private readonly TagTestScope _scope = new();
    private static char[] Password => "a memorable test password 42".ToCharArray();
    private string FilePath => Path.Combine(_scope.DirectoryPath, "report's data.txt");
    private FileLockService Service => new(_scope.DatabasePath);
    [TestCleanup] public void Cleanup() => _scope.Dispose();

    [TestMethod]
    [DataRow(0)] [DataRow(12345)]
    public void LockEncryptsBytesAndUnlockRestoresThemAfterRestart(int length)
    {
        var original = RandomNumberGenerator.GetBytes(length);
        File.WriteAllBytes(FilePath, original);
        using (var tags = _scope.Open()) tags.Assign(FilePath, "work");
        Assert.IsTrue(Service.Transform(FilePath, Password, true).Locked);
        Assert.IsTrue(FileLockService.IsLocked(FilePath));
        Assert.AreEqual(length + FileLockFormat.HeaderSize, new FileInfo(FilePath).Length);
        using (var store = new FileLockStore(_scope.DatabasePath)) Assert.AreEqual("Locked", store.State(FilePath));
        Assert.IsFalse(Service.Transform(FilePath, Password, false).Locked);
        CollectionAssert.AreEqual(original, File.ReadAllBytes(FilePath));
        Assert.AreEqual(0L, _scope.Number("SELECT COUNT(*) FROM LockedFiles"));
        using (var tags = _scope.Open()) Assert.IsTrue(tags.HasTag(FilePath, "work"));
    }

    [TestMethod]
    public void WrongPasswordAndDamagedContentNeverChangeTheLockedFile()
    {
        File.WriteAllText(FilePath, "private contents");
        Service.Transform(FilePath, Password, true);
        var locked = File.ReadAllBytes(FilePath);
        Assert.ThrowsException<CryptographicException>(() => Service.Transform(FilePath, "wrong password".ToCharArray(), false));
        CollectionAssert.AreEqual(locked, File.ReadAllBytes(FilePath));
        locked[^1] ^= 1;
        File.WriteAllBytes(FilePath, locked);
        Assert.ThrowsException<CryptographicException>(() => Service.Transform(FilePath, Password, false));
        CollectionAssert.AreEqual(locked, File.ReadAllBytes(FilePath));
        Assert.AreEqual(0, Directory.GetFiles(_scope.DirectoryPath, ".clearspace-lock-*.tmp").Length);
    }

    [TestMethod]
    [DataRow(8)] [DataRow(36)] [DataRow(68)] [DataRow(80)] [DataRow(112)] [DataRow(128)] [DataRow(140)]
    public void HeaderTamperingIsAuthenticated(int offset)
    {
        var encrypted = FileLockFormat.Encrypt("contents"u8.ToArray(), Password);
        encrypted.Header[offset] ^= 1;
        Assert.ThrowsException<CryptographicException>(() => FileLockFormat.Decrypt(encrypted.Header, encrypted.Ciphertext, Password));
    }

    [TestMethod]
    public void TruncationLengthAndWorkFactorAreRejectedBeforeDecryption()
    {
        var encrypted = FileLockFormat.Encrypt("contents"u8.ToArray(), Password);
        Assert.ThrowsException<InvalidDataException>(() => FileLockFormat.Decrypt(encrypted.Header, encrypted.Ciphertext[..^1], Password));
        encrypted.Header[24] ^= 1;
        Assert.ThrowsException<InvalidDataException>(() => FileLockFormat.Decrypt(encrypted.Header, encrypted.Ciphertext, Password));
    }

    [TestMethod]
    public void RenamedFileCanBeUnlockedWithAnEntirelyNewDatabase()
    {
        File.WriteAllText(FilePath, "portable recovery");
        Service.Transform(FilePath, Password, true);
        var moved = Path.Combine(_scope.DirectoryPath, "renamed.txt");
        File.Move(FilePath, moved);
        new FileLockService(Path.Combine(_scope.DirectoryPath, "fresh.db")).Transform(moved, Password, false);
        Assert.AreEqual("portable recovery", File.ReadAllText(moved));
    }

    [TestMethod]
    public void SamePasswordProducesIndependentFileKeysAndNonces()
    {
        var first = FileLockFormat.Encrypt("same"u8.ToArray(), Password);
        var second = FileLockFormat.Encrypt("same"u8.ToArray(), Password);
        Assert.IsFalse(first.Header.AsSpan(36, 32).SequenceEqual(second.Header.AsSpan(36, 32)));
        Assert.IsFalse(first.Header.AsSpan(80, 32).SequenceEqual(second.Header.AsSpan(80, 32)));
        Assert.IsFalse(first.Ciphertext.SequenceEqual(second.Ciphertext));
    }

    [TestMethod]
    public void ExistingMasterPasswordCannotBeSilentlyChanged()
    {
        using var store = new FileLockStore(_scope.DatabasePath);
        store.CheckOrCreatePassword(Password);
        Assert.ThrowsException<CryptographicException>(() => store.CheckOrCreatePassword("a different password".ToCharArray()));
        store.CheckOrCreatePassword(Password);
        Assert.AreEqual(1L, _scope.Number("SELECT COUNT(*) FROM LockSettings"));
        store.Dispose();
        Assert.IsFalse(Encoding.UTF8.GetString(File.ReadAllBytes(_scope.DatabasePath)).Contains(new string(Password)));
    }

    [TestMethod]
    [DataRow("Recorded")] [DataRow("Prepared")]
    public void FailureBeforeReplacementPreservesOriginalAndAllowsRetry(string boundary)
    {
        File.WriteAllText(FilePath, "still readable");
        var service = new FileLockService(_scope.DatabasePath) { Checkpoint = stage => { if (stage == boundary) throw new IOException("Injected interruption"); } };
        Assert.ThrowsException<IOException>(() => service.Transform(FilePath, Password, true));
        Assert.AreEqual("still readable", File.ReadAllText(FilePath));
        Assert.AreEqual(0, Directory.GetFiles(_scope.DirectoryPath, ".clearspace-lock-*.tmp").Length);
        Service.Transform(FilePath, Password, true);
        Service.Transform(FilePath, Password, false);
        Assert.AreEqual("still readable", File.ReadAllText(FilePath));
    }

    [TestMethod]
    public void FailureAfterReplacementKeepsRecoverableFileDespitePendingDatabaseState()
    {
        File.WriteAllText(FilePath, "recover me");
        var service = new FileLockService(_scope.DatabasePath) { Checkpoint = stage => { if (stage == "Replaced") throw new IOException("Injected process interruption"); } };
        Assert.ThrowsException<IOException>(() => service.Transform(FilePath, Password, true));
        Assert.IsTrue(FileLockService.IsLocked(FilePath));
        using (var store = new FileLockStore(_scope.DatabasePath)) Assert.AreEqual("Preparing", store.State(FilePath));
        Service.Transform(FilePath, Password, false);
        Assert.AreEqual("recover me", File.ReadAllText(FilePath));
    }

    [TestMethod]
    public void DatabaseFailureBeforeReplacementLeavesOriginalUntouched()
    {
        File.WriteAllText(FilePath, "do not lose");
        using (var store = new FileLockStore(_scope.DatabasePath)) store.CheckOrCreatePassword(Password);
        _scope.Execute("CREATE TRIGGER FailLock BEFORE INSERT ON LockedFiles BEGIN SELECT RAISE(ABORT,'injected'); END");
        Assert.ThrowsException<Microsoft.Data.Sqlite.SqliteException>(() => Service.Transform(FilePath, Password, true));
        Assert.AreEqual("do not lose", File.ReadAllText(FilePath));
    }

    [TestMethod]
    public void DatabaseFailureAfterReplacementReportsSuccessWithRecoveryWarning()
    {
        File.WriteAllText(FilePath, "database failure");
        using (var store = new FileLockStore(_scope.DatabasePath)) store.CheckOrCreatePassword(Password);
        _scope.Execute("CREATE TRIGGER FailFinish BEFORE UPDATE ON LockedFiles WHEN NEW.State='Locked' BEGIN SELECT RAISE(ABORT,'injected'); END");
        var result = Service.Transform(FilePath, Password, true);
        Assert.IsTrue(result.Locked);
        Assert.IsNotNull(result.Warning);
        Service.Transform(FilePath, Password, false);
        Assert.AreEqual("database failure", File.ReadAllText(FilePath));
    }

    [TestMethod]
    public void CancellationDuringPreparationPreservesOriginal()
    {
        File.WriteAllText(FilePath, "cancel me");
        using var cancellation = new CancellationTokenSource();
        var service = new FileLockService(_scope.DatabasePath) { Checkpoint = stage => { if (stage == "Prepared") cancellation.Cancel(); } };
        Assert.ThrowsException<OperationCanceledException>(() => service.Transform(FilePath, Password, true, cancellation.Token));
        Assert.AreEqual("cancel me", File.ReadAllText(FilePath));
    }

    [TestMethod]
    public void WritableOpenFileAndAdditionalDataStreamsAreRejected()
    {
        File.WriteAllText(FilePath, "busy");
        using (var writer = new FileStream(FilePath, FileMode.Open, FileAccess.Write, FileShare.ReadWrite | FileShare.Delete))
            Assert.ThrowsException<IOException>(() => Service.Transform(FilePath, Password, true));
        File.WriteAllText(FilePath + ":extra", "secret stream");
        Assert.ThrowsException<IOException>(() => Service.Transform(FilePath, Password, true));
        Assert.AreEqual("busy", File.ReadAllText(FilePath));
        Assert.AreEqual("secret stream", File.ReadAllText(FilePath + ":extra"));
    }

    [TestMethod]
    public void HardLinksAndOversizedFilesAreRejected()
    {
        File.WriteAllText(FilePath, "linked");
        var link = Path.Combine(_scope.DirectoryPath, "alias.txt");
        Assert.IsTrue(CreateHardLinkW(link, FilePath, IntPtr.Zero));
        Assert.ThrowsException<IOException>(() => Service.Transform(FilePath, Password, true));
        File.Delete(link);
        using (var file = File.OpenWrite(FilePath)) file.SetLength(FileLockFormat.MaxFileSize + 1L);
        Assert.ThrowsException<IOException>(() => Service.Transform(FilePath, Password, true));
        Assert.AreEqual(FileLockFormat.MaxFileSize + 1L, new FileInfo(FilePath).Length);
    }

    [TestMethod]
    public void TargetReplacementDuringPreparationIsDetected()
    {
        File.WriteAllText(FilePath, "original");
        var moved = Path.Combine(_scope.DirectoryPath, "original-moved.txt");
        var service = new FileLockService(_scope.DatabasePath) { Checkpoint = stage =>
        {
            if (stage != "Prepared") return;
            File.Move(FilePath, moved);
            File.WriteAllText(FilePath, "different file");
        } };
        Assert.ThrowsException<IOException>(() => service.Transform(FilePath, Password, true));
        Assert.AreEqual("original", File.ReadAllText(moved));
        Assert.AreEqual("different file", File.ReadAllText(FilePath));
    }

    [TestMethod]
    public void VersionOneDatabaseUpgradeKeepsTagsAndAddsLockTables()
    {
        using (var tags = _scope.Open()) tags.Assign("existing", "work");
        _scope.Execute("DROP TABLE LockedFiles; DROP TABLE LockSettings; PRAGMA user_version=1;");
        using var upgraded = new FileLockStore(_scope.DatabasePath);
        Assert.IsFalse(upgraded.HasPassword);
        Assert.AreEqual(2L, _scope.Number("PRAGMA user_version"));
        Assert.AreEqual(1L, _scope.Number("SELECT COUNT(*) FROM PathTags WHERE Path='existing'"));
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)] private static extern bool CreateHardLinkW(string link, string existing, IntPtr attributes);
}
