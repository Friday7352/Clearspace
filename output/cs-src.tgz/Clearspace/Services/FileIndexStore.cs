// Clearspace | Persistent file-index storage.

using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace Clearspace.Services;

internal static class FileIndexStore
{
    private const int Magic = 0x58495343; // 'CSIX'

    // Version 3 invalidates depth-limited indexes. The binary layout is unchanged;
    // a one-time background rebuild includes descendants beyond the former 32-level limit.
    private const int FormatVersion = 3;

    private const int MaxEntries = 40_000_000;
    private const int MaxPool = 800_000_000;

    private static readonly string Directory_ = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "Clearspace");

    internal static string FilePath => Path.Combine(Directory_, "index.db");

    // NEW: periodic background saves and the save on exit must not write the file at once.
    private static readonly object SaveGate = new();

    // CHANGED (journal catch-up): reports success, so change-journal positions are only recorded
    // alongside an index file that was actually written.
    public static bool Save(IReadOnlyList<VolumeIndex> volumes)
    {
        lock (SaveGate)
            return SaveCore(volumes);
    }

    private static bool SaveCore(IReadOnlyList<VolumeIndex> volumes)
    {
        try
        {
            System.IO.Directory.CreateDirectory(Directory_);

            var temporary = FilePath + ".tmp";

            using (var stream = new FileStream(temporary, FileMode.Create, FileAccess.Write, FileShare.None))
            using (var writer = new BinaryWriter(stream, System.Text.Encoding.UTF8, leaveOpen: true))
            {
                writer.Write(Magic);
                writer.Write(FormatVersion);
                writer.Write(volumes.Count);

                foreach (var live in volumes)
                {
                    // CHANGED (live index): hold the volume's write lock so live updates can't
                    // change it mid-write, and drop entries removed since the last full scan.
                    lock (live.WriteGate)
                    {
                        // CHANGED (memory): removed entries are skipped while writing, not by copying the index.
                        if (live.RemovedCount > 0)
                        {
                            live.WriteCompactedLocked(writer);
                            continue;
                        }

                        writer.Write(live.Root);
                        writer.Write(live.SerialNumber);
                        writer.Write(live.BuiltUtc.Ticks);
                        writer.Write(live.Count);
                        writer.Write(live.PoolLength);
                        writer.Flush();

                        stream.Write(MemoryMarshal.AsBytes(live.Entries.AsSpan(0, live.Count)));
                        stream.Write(MemoryMarshal.AsBytes(live.Names.AsSpan(0, live.PoolLength)));
                    }
                }
            }

            File.Move(temporary, FilePath, overwrite: true);
            foreach (var volume in volumes) volume.MarkSaved(); // NEW
            return true;
        }
        catch (Exception exception)
        {
            Trace.WriteLine($"Clearspace: could not save the file index. {exception.Message}");
            return false;
        }
    }

    public static List<VolumeIndex> Load()
    {
        var volumes = new List<VolumeIndex>();

        try
        {
            if (!File.Exists(FilePath))
                return volumes;

            using var stream = new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            using var reader = new BinaryReader(stream, System.Text.Encoding.UTF8, leaveOpen: true);

            if (reader.ReadInt32() != Magic || reader.ReadInt32() != FormatVersion)
                return volumes;

            var count = reader.ReadInt32();

            if (count is < 0 or > 64)
                return volumes;

            for (var i = 0; i < count; i++)
            {
                var root = reader.ReadString();
                var serial = reader.ReadUInt32();
                var builtTicks = reader.ReadInt64();
                var entryCount = reader.ReadInt32();
                var poolLength = reader.ReadInt32();

                if (entryCount is < 0 or > MaxEntries || poolLength is < 0 or > MaxPool)
                    return volumes;

                var entries = new IndexEntry[Math.Max(1, entryCount)];
                var names = new char[Math.Max(1, poolLength)];

                stream.ReadExactly(MemoryMarshal.AsBytes(entries.AsSpan(0, entryCount)));
                stream.ReadExactly(MemoryMarshal.AsBytes(names.AsSpan(0, poolLength)));

                // CHANGED (round 50): a network drive's index is kept while network indexing is on, even
                // when the share is out of reach right now (its sizes are still worth seeing, and indexing
                // a NAS again is slow); it is dropped when network indexing is off. Asking an unreachable
                // server for its serial number could also take a long time, so it is not asked.
                if (NetworkDrives.IsNetworkRoot(root))
                {
                    if (!NetworkDrives.Enabled) continue;
                }
                else if (FileIndexBuilder.GetSerialNumber(root) != serial)
                    continue;

                volumes.Add(new VolumeIndex(
                    root,
                    serial,
                    new DateTime(builtTicks, DateTimeKind.Utc),
                    entries,
                    entryCount,
                    names,
                    poolLength));
            }
        }
        catch (Exception exception)
        {
            Trace.WriteLine($"Clearspace: could not load the file index. {exception.Message}");
            return [];
        }

        return volumes;
    }

    public static void Delete()
    {
        try
        {
            if (File.Exists(FilePath))
                File.Delete(FilePath);
        }
        catch (Exception)
        {
        }
    }
}
