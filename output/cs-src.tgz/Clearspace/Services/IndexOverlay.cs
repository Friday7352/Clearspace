// Clearspace | Bounded changes and recovery generations, isolated by volume.
using System.IO;
using Clearspace.Models;

namespace Clearspace.Services;

internal sealed class IndexOverlay
{
    private const int MaxTracked = 100_000;
    private const int MaxRemovedTrees = 256;
    private readonly Lock _gate = new();
    private readonly Dictionary<string, Changes> _volumes = new(StringComparer.OrdinalIgnoreCase);

    private sealed class Changes
    {
        public readonly HashSet<string> Added = new(StringComparer.OrdinalIgnoreCase);
        public readonly HashSet<string> Removed = new(StringComparer.OrdinalIgnoreCase);
        public readonly List<string> RemovedTrees = [];
        public long Generation;
        public bool Overflowed;
        public string? LostBecause; // NEW (search fix): why the drive last dropped out, for the search trace
        public int Count => Added.Count + Removed.Count;
        public void Clear()
        {
            Added.Clear(); Removed.Clear(); RemovedTrees.Clear();
            Added.TrimExcess(); Removed.TrimExcess();
        }
    }

    // Delivered outside the lock; the service queues a rescan of only this root.
    public event Action<string>? LostChanges;
    private static string Root(string path) => (Path.GetPathRoot(path) ?? path).TrimEnd('\\', '/') + "\\";
    private Changes Get(string root)
    {
        if (!_volumes.TryGetValue(root, out var changes)) _volumes[root] = changes = new();
        return changes;
    }

    public int Count { get { lock (_gate) return _volumes.Values.Sum(changes => changes.Count); } }
    public bool IsHealthy(string root)
    {
        lock (_gate) return !_volumes.TryGetValue(Root(root), out var changes) || !changes.Overflowed;
    }

    public long Generation(string root)
    {
        lock (_gate) return Get(Root(root)).Generation;
    }

    // Only a successfully published replacement may recover a volume. New failures during
    // a scan change the generation and cannot be erased by an older scan finishing.
    public bool TryRecover(string root, long generation)
    {
        lock (_gate)
        {
            var changes = Get(Root(root));
            if (changes.Generation != generation) return false;
            changes.Clear();
            changes.Overflowed = false;
            return true;
        }
    }

    public void MarkOverflowed(string root)
    {
        root = Root(root);
        lock (_gate)
        {
            var changes = Get(root);
            Lose(changes);
            changes.LostBecause = "changes were missed (the watcher overflowed, could not start, or an update failed)";
        }
        LostChanges?.Invoke(root);
    }

    // NEW (search fix): why a drive last dropped out of live coverage, in words.
    public string WhyLost(string root)
    {
        lock (_gate) return _volumes.TryGetValue(Root(root), out var changes) ? changes.LostBecause ?? "unknown" : "unknown";
    }

    // NEW (search fix): the index itself has dealt with these paths (FileIndexUpdater applied the change, or
    // found there was nothing to apply), so they no longer need to be remembered here.
    // This list used to keep every path created or deleted since the drive was last caught up. Two things
    // followed. A search checked every remembered new path on the disk, on each key press, and that list
    // only grew while Clearspace was open. And after 256 remembered deletions - a few minutes of temporary
    // files coming and going - the drive was declared "lost": searches then crawled the whole drive from
    // the disk until the index caught up again. Now only changes the index has not reached yet are kept,
    // which is a fraction of a second's worth.
    public void Settle(IReadOnlyList<string> paths)
    {
        lock (_gate)
        {
            foreach (var path in paths)
            {
                if (string.IsNullOrEmpty(path) || !_volumes.TryGetValue(Root(path), out var changes))
                    continue;

                changes.Added.Remove(path);
                if (changes.Removed.Remove(path))
                    changes.RemovedTrees.RemoveAll(tree => tree.Equals(path, StringComparison.OrdinalIgnoreCase));
            }
        }
    }

    private static void Lose(Changes changes)
    {
        changes.Generation++;
        changes.Overflowed = true;
        changes.Clear();
    }

    public void OnCreated(string path) => Record(path, false);
    public void OnDeleted(string path) => Record(path, true);
    public void OnRenamed(string oldPath, string newPath)
    {
        OnDeleted(oldPath);
        OnCreated(newPath);
    }

    private void Record(string path, bool deleted)
    {
        if (string.IsNullOrEmpty(path)) return;
        var root = Root(path);
        var lost = false;
        lock (_gate)
        {
            var changes = Get(root);
            if (changes.Overflowed) return;
            if (deleted)
            {
                changes.Added.Remove(path);
                changes.Removed.Add(path);
                // A deleted directory may contain dots; event args do not tell us its kind.
                if (!changes.RemovedTrees.Contains(path, StringComparer.OrdinalIgnoreCase))
                    changes.RemovedTrees.Add(path);
            }
            else
            {
                changes.Removed.Remove(path);
                changes.RemovedTrees.RemoveAll(tree => tree.Equals(path, StringComparison.OrdinalIgnoreCase));
                changes.Added.Add(path);
            }
            if (changes.RemovedTrees.Count > MaxRemovedTrees || _volumes.Values.Sum(value => value.Count) > MaxTracked)
            {
                var why = changes.RemovedTrees.Count > MaxRemovedTrees
                    ? $"more than {MaxRemovedTrees} deletions were waiting to reach the index"
                    : $"more than {MaxTracked:N0} changes were waiting to reach the index";
                Lose(changes);
                changes.LostBecause = why;
                lost = true;
            }
        }
        if (lost) LostChanges?.Invoke(root);
    }

    public bool IsRemoved(string path)
    {
        lock (_gate)
        {
            if (!_volumes.TryGetValue(Root(path), out var changes)) return false;
            return changes.Removed.Contains(path) || changes.RemovedTrees.Any(tree =>
                path.Length > tree.Length && path.StartsWith(tree, StringComparison.OrdinalIgnoreCase) &&
                path[tree.Length] == Path.DirectorySeparatorChar);
        }
    }

    // NEW (search relevance): paths added since the last full scan. The index search evaluates them
    // with the whole query (tags, folders, types), so it no longer uses CollectMatches' filename filter.
    public string[] AddedPaths()
    {
        lock (_gate) return [.. _volumes.Values.Where(changes => !changes.Overflowed).SelectMany(changes => changes.Added)];
    }

    public void CollectMatches(IReadOnlyList<string> foldedTerms, bool showHidden, int limit, List<FileSystemItem> results)
    {
        string[] candidates;
        lock (_gate) candidates = [.. _volumes.Values.Where(changes => !changes.Overflowed).SelectMany(changes => changes.Added)];
        foreach (var path in candidates)
        {
            if (results.Count >= limit) return;
            var name = Path.GetFileName(path);
            if (name.Length == 0) continue;
            var folded = name.ToLowerInvariant();
            if (foldedTerms.Any(term => !folded.Contains(term, StringComparison.Ordinal))) continue;
            var item = FileSystemItem.FromLocation(path);
            if (item is null || (!showHidden && (item.IsHidden || (item.Attributes & FileAttributes.System) != 0))) continue;
            results.Add(item);
        }
    }
}
