namespace Clearspace.ViewModels;

public sealed record SidebarEntry(
    string Name,
    string Path,
    bool IsHeader = false,
    bool IsPinned = false,
    bool IsKnownFolder = false,
    bool IsNetworkDrive = false,
    bool IsPinnedRoot = false,
    bool IsCategory = false,
    string? CategoryId = null,
    bool IsCollapsed = false,
    bool IsSection = false,
    string? SectionId = null,
    bool IsChild = false,
    string? CloudProvider = null,
    bool IsLibrary = false) // NEW (your files): a folder you added to Your files (it can be taken off again)
{
    public string DisplayName => Name;
    public string CollapseGlyph => IsCollapsed ? "\uE76C" : "\uE70D";
    public bool HasHub => IsSection && !string.IsNullOrWhiteSpace(Path);
    public bool IsNestedPin => IsPinned;

    // NEW (map network drive): the This PC and Network headings have "Map network drive…" in their menu.
    public bool OffersMapDrive => IsSection && SectionId is "this-pc" or "network";

    public bool IsCloudBacked => !string.IsNullOrWhiteSpace(CloudProvider);

    public string CloudHint => IsCloudBacked
        ? $"Backed up by {CloudProvider}"
        : string.Empty;
}
