// Clearspace | Main file-browser state and operations.

using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using Clearspace.Commands;
using Clearspace.Models;
using Clearspace.Native;
using Clearspace.Services;

namespace Clearspace.ViewModels;

public sealed class MainViewModel : ObservableObject, IDisposable
{
    public const string MyPcPath = ExplorerLocations.MyPcPath;
    public const string NetworkPath = ExplorerLocations.NetworkPath;
    public const string YourFilesPath = ExplorerLocations.YourFilesPath;
    public const string PinnedPath = ExplorerLocations.PinnedPath;
    public const string CloudPath = ExplorerLocations.CloudPath;
    public const string CategoryPathPrefix = ExplorerLocations.CategoryPathPrefix;

    private readonly NavigationCoordinator _navigationLoads = new();
    private readonly SearchCoordinator _search;

    // CHANGED (tab to new window): takes the history a window starts with (a tab moved out of another
    // window brings its own); null for an ordinary new window.
    public MainViewModel(NavigationHistory? history = null)
    {
        // CHANGED (search trace): a search that takes 1.5 seconds or more leaves a line in search-trace.log.
        // CHANGED (search fix): the search hands over the same list again when its rows have not changed, and
        // Items then stays as it is (SetProperty sees the same object), so the window does not rebuild its
        // rows. Each real replacement is counted and labelled for the search trace.
        _search = new SearchCoordinator(new SearchSources(), update =>
        {
            if (!ReferenceEquals(_items, update.Items))
                SearchTrace.ListReplaced();

            using (SearchTrace.During("replacing the list with search results"))
            {
                Items = update.Items;
                IsSearchingTree = update.IsSearching;
                if (update.Status is not null) StatusText = update.Status;
            }
        }, trace: SearchTrace.Write);
        _folderWatcher = new FolderWatcher(OnFolderChangedOnDisk); // NEW (live folder): made here, on the UI thread, so its calls come back to it
        Navigation = new NavigationService(history); // CHANGED (tab to new window): was new NavigationService()
        Context = new ExplorerContext { Navigation = Navigation };
        Context.Notify = ReportStatus; // NEW (zip folders): "Opened a copy of ...", from the Open and Copy actions
        Commands = new CommandManager(Context);

        // NEW (tabs): the window starts with one tab, which takes over Navigation's history. A new tab
        // starts in your user folder, the same place Clearspace itself starts. Each tab keeps its own
        // search: it is put aside when you leave the tab and typed back in when you return.
        Tabs = new ExplorerTabs(Navigation, () => KnownFolders.Profile, TabTitle);
        Context.Tabs = Tabs;
        Tabs.Deactivating += (_, tab) => tab.SearchText = SearchText;
        Tabs.Activated += (_, tab) => SearchText = tab.SearchText;
        Tabs.Changed += (_, _) => Commands.RefreshState();

        Navigation.Navigated += async (_, path) => await LoadAsync(path);
        Context.RefreshRequested += async (_, _) => await RefreshAsync();
        Context.SelectionChanged += (_, _) =>
        {
            Commands.RefreshState();
            UpdateStatus();
            OnPropertyChanged(nameof(HasSelectedFolders));
            OnPropertyChanged(nameof(HasCloudSelection));
            OnPropertyChanged(nameof(CanPinToProject)); // NEW (folder types, step 2)
            OnPropertyChanged(nameof(CanRemoveFromYourFiles)); // NEW (your files)
            RefreshTagOptions();
        };

        // NEW (status line): "Delete: Completed." and the like go away by themselves.
        Context.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(ExplorerContext.LastFileOperation))
                ScheduleFileOperationClear();
        };

        TagService.Changed += OnTagsChanged;

        FileIndexService.Changed += OnFileIndexChanged;
        LoadColumns();
        RefreshTagOptions();

        SearchEverywhere = SettingsService.GetSearchEverywhere();
        UseWindowsIndex = SettingsService.GetUseWindowsIndex();
        SearchFileContents = SettingsService.GetSearchFileContents();
        ShowHiddenItems = SettingsService.GetShowHiddenItems();
    }

    // ------------------------------------------------------------------ NEW (status line)
    // The line under the status text that reports a copy, move, rename or delete used to stay until the
    // next operation replaced it. It now clears itself: a result that needs no attention ("Completed.")
    // after a few seconds, one that says something went wrong or was cancelled after longer, since that
    // is the one worth reading.
    private static readonly TimeSpan FileOperationSuccessTime = TimeSpan.FromSeconds(4);
    private static readonly TimeSpan FileOperationProblemTime = TimeSpan.FromSeconds(12);

    private DispatcherTimer? _fileOperationTimer;

    private void ScheduleFileOperationClear()
    {
        _fileOperationTimer?.Stop();

        if (Context.LastFileOperation is not { } result)
            return;

        if (_fileOperationTimer is null)
        {
            var timer = new DispatcherTimer();
            timer.Tick += (_, _) =>
            {
                timer.Stop();
                Context.ClearFileOperation();
            };
            _fileOperationTimer = timer;
        }

        _fileOperationTimer.Interval = result.Succeeded ? FileOperationSuccessTime : FileOperationProblemTime;
        _fileOperationTimer.Start();
    }

    public NavigationService Navigation { get; }

    // NEW (tabs): the tab strip. Navigation always works on the active tab's history.
    public ExplorerTabs Tabs { get; }

    // NEW (tabs): the name on a tab is the last part of the address bar's trail for that location.
    private static string TabTitle(string path)
        => BuildBreadcrumbs(path) is { Count: > 0 } crumbs ? crumbs[^1].Name : path;

    public ExplorerContext Context { get; }

    public CommandManager Commands { get; }

    public SidebarViewModel SidebarState { get; } = new();
    public ObservableCollection<SidebarEntry> Sidebar => SidebarState.Sidebar;

    public AudioPlayerViewModel Player { get; } = new();

    public PhotoViewerViewModel Viewer { get; } = new();


    public ObservableCollection<ColumnOption> ColumnOptions { get; } = [];

    public event EventHandler? ColumnsChanged;

    private List<string> _visibleColumns = [];

    public IReadOnlyList<string> VisibleColumns => _visibleColumns;

    public double? GetColumnWidth(string columnId)
        => string.IsNullOrWhiteSpace(CurrentPath)
            ? null
            : SettingsService.GetFolderColumnWidth(CurrentPath, columnId);

    public void SaveColumnWidth(string columnId, double width)
    {
        if (!string.IsNullOrWhiteSpace(CurrentPath))
            SettingsService.SetFolderColumnWidth(CurrentPath, columnId, width);
    }

    public void SaveColumnOrder(IEnumerable<string> columnIds)
    {
        var visible = new HashSet<string>(_visibleColumns, StringComparer.OrdinalIgnoreCase);
        var ordered = ColumnCatalog.Sanitise(columnIds)
            .Where(visible.Contains)
            .ToList();

        if (ordered.Count != _visibleColumns.Count)
            return;

        _visibleColumns = ordered;
        if (!string.IsNullOrWhiteSpace(CurrentPath))
            SettingsService.SetFolderColumns(CurrentPath, _visibleColumns);
    }

    private void LoadColumns()
    {
        // CHANGED (folder types): the type in effect here (own, inherited, or detected) supplies the defaults.
        var type = string.IsNullOrWhiteSpace(CurrentPath) ? FolderTypes.General : FolderTypes.Resolved(CurrentPath);

        var saved = string.IsNullOrWhiteSpace(CurrentPath)
            ? null
            : SettingsService.GetFolderColumns(CurrentPath);

        _visibleColumns = ColumnCatalog.Sanitise(saved ?? FolderTypes.DefaultColumns(type, IsCloudFolder));

        ColumnOptions.Clear();

        foreach (var info in ColumnCatalog.All)
        {
            ColumnOptions.Add(new ColumnOption(
                info,
                _visibleColumns.Contains(info.Id, StringComparer.OrdinalIgnoreCase),
                OnColumnToggled));
        }

        ColumnsChanged?.Invoke(this, EventArgs.Empty);
    }

    private void OnColumnToggled(ColumnOption option)
    {
        if (option.IsVisible)
        {
            if (!_visibleColumns.Contains(option.Id, StringComparer.OrdinalIgnoreCase))
            {
                var target = ColumnCatalog.All
                    .TakeWhile(info => !info.Id.Equals(option.Id, StringComparison.OrdinalIgnoreCase))
                    .Select(info => _visibleColumns.FindIndex(id => id.Equals(info.Id, StringComparison.OrdinalIgnoreCase)))
                    .Where(index => index >= 0)
                    .DefaultIfEmpty(-1)
                    .Max();

                _visibleColumns.Insert(target + 1, option.Id);
            }
        }
        else
        {
            _visibleColumns.RemoveAll(id => id.Equals(option.Id, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(CurrentPath))
            SettingsService.SetFolderColumns(CurrentPath, _visibleColumns);

        ColumnsChanged?.Invoke(this, EventArgs.Empty);
    }

    public void ResetColumns()
    {
        if (!string.IsNullOrWhiteSpace(CurrentPath))
            SettingsService.ClearFolderColumns(CurrentPath);

        LoadColumns();
    }

    // CHANGED (zip folders): the player and the photo viewer read files from a disk, so neither takes
    // something that is inside a ZIP file (Open takes a copy out and gives it to its usual program).
    public void PlayTrack(FileSystemItem item)
    {
        if (item.IsAudio && !item.IsInArchive)
            Player.Play(Items, item);
    }

    public void ViewPhoto(FileSystemItem item)
    {
        if (item.IsImageFile && !item.IsInArchive)
            Viewer.Open(Items, item);
    }

    public RichCommand BackCommand => Commands[CommandCode.NavigateBack];
    public RichCommand ForwardCommand => Commands[CommandCode.NavigateForward];
    public RichCommand UpCommand => Commands[CommandCode.NavigateUp];
    public RichCommand HomeCommand => Commands[CommandCode.NavigateHome];
    public RichCommand RefreshCommand => Commands[CommandCode.Refresh];
    public RichCommand OpenCommand => Commands[CommandCode.OpenItem];
    public RichCommand DeleteCommand => Commands[CommandCode.Delete];
    public RichCommand RenameCommand => Commands[CommandCode.Rename];
    public RichCommand CopyCommand => Commands[CommandCode.CopyItem];
    public RichCommand CutCommand => Commands[CommandCode.CutItem];
    public RichCommand PasteCommand => Commands[CommandCode.PasteItem];
    public RichCommand CopyPathCommand => Commands[CommandCode.CopyPath];
    public RichCommand NewFolderCommand => Commands[CommandCode.NewFolder];
    public RichCommand PropertiesCommand => Commands[CommandCode.ShowProperties];
    public RichCommand TerminalCommand => Commands[CommandCode.OpenTerminal];
    public RichCommand NewTabCommand => Commands[CommandCode.NewTab];             // NEW (tabs)
    public RichCommand OpenInNewTabCommand => Commands[CommandCode.OpenInNewTab]; // NEW (tabs)
    public RichCommand OpenInNewWindowCommand => Commands[CommandCode.OpenInNewWindow]; // NEW (new window)
    public RichCommand PreviewPaneCommand => Commands[CommandCode.TogglePreviewPane];   // NEW (preview pane)
    public RichCommand InspectorCommand => Commands[CommandCode.ToggleInspector];       // NEW (inspector)
    public RichCommand ShelfCommand => Commands[CommandCode.ToggleShelf];               // NEW (shelf)
    public RichCommand AddToShelfCommand => Commands[CommandCode.AddToShelf];           // NEW (shelf)
    public RichCommand MapNetworkDriveCommand => Commands[CommandCode.MapNetworkDrive]; // NEW (map network drive)

    private IReadOnlyList<FileSystemItem> _items = [];
    public IReadOnlyList<FileSystemItem> Items
    {
        get => _items;
        private set => SetProperty(ref _items, value);
    }

    private IReadOnlyList<FileSystemItem> _directoryItems = [];

    private string _searchText = string.Empty;
    public string SearchText
    {
        get => _searchText;
        set
        {
            if (!SetProperty(ref _searchText, value))
                return;

            // CHANGED (search fix): labelled for the search trace, and the list's grouping is no longer
            // changed here. Announcing ListGrouping on every letter took the date or kind groups off the
            // folder's list as the first letter was typed (rebuilding every row), a moment before the
            // results replaced that list anyway. The window sets the grouping whenever the list itself is
            // replaced (MainWindow.ApplyGrouping), which covers both starting and clearing a search.
            using (SearchTrace.During("the search box: its text changed"))
            {
                OnPropertyChanged(nameof(HasSearch));
                OnPropertyChanged(nameof(ShowsProjectStrip)); // NEW (folder types, step 2)
                ApplySearchFilter(updateStatus: true);

                // NEW (live folder): the folder changed on the disk while a search was showing; catch up now.
                if (!HasSearch && _changedDuringSearch)
                    OnFolderChangedOnDisk();
            }
        }
    }

    public bool HasSearch => !string.IsNullOrWhiteSpace(SearchText);

    private bool _searchEverywhere;
    public bool SearchEverywhere
    {
        get => _searchEverywhere;
        set
        {
            if (!SetProperty(ref _searchEverywhere, value))
                return;

            SettingsService.SetSearchEverywhere(value);
            ApplySearchFilter(updateStatus: true);
        }
    }


    public ObservableCollection<TagOption> TagOptions { get; } = [];

    private void RefreshTagOptions()
    {
        var paths = Context.SelectedItems.Select(item => item.FullPath).ToArray();

        TagOptions.Clear();

        foreach (var tag in TagService.All)
        {
            var applied = paths.Length > 0 && paths.All(path => TagService.HasTag(path, tag.Id));
            TagOptions.Add(new TagOption(tag, applied, OnTagToggled));
        }
    }

    // CHANGED (zip folders): tags belong to files and folders on a disk. Things inside a ZIP file are
    // left out here and in the two methods below (the Tags menu is hidden for them as well).
    private void OnTagToggled(TagOption option)
    {
        var paths = Context.SelectedItems.Where(item => !item.IsInArchive).Select(item => item.FullPath).ToArray();
        if (paths.Length == 0)
            return;

        if (!TryUpdateTags(() => TagService.ToggleForAll(paths, option.Tag.Id))) return;
        RefreshVisibleTags();

        var count = paths.Length == 1 ? "1 item" : $"{paths.Length:N0} items";
        StatusText = option.IsApplied
            ? $"Tagged {count} as {option.Tag.Name}."
            : $"Removed {option.Tag.Name} from {count}.";
    }

    public void CreateTagForSelection(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            return;

        var paths = Context.SelectedItems.Where(item => !item.IsInArchive).Select(item => item.FullPath).ToArray();
        TagDefinition? tag = null;
        if (!TryUpdateTags(() => tag = TagService.CreateForPaths(name, paths))) return;

        RefreshVisibleTags();
        RefreshTagOptions();
        StatusText = paths.Length == 0
            ? $"Created the {tag!.Name} tag."
            : $"Tagged {paths.Length:N0} item{(paths.Length == 1 ? string.Empty : "s")} as {tag!.Name}.";
    }

    public void ClearTagsOnSelection()
    {
        var paths = Context.SelectedItems.Where(item => !item.IsInArchive).Select(item => item.FullPath).ToArray();
        if (paths.Length == 0)
            return;

        if (!TryUpdateTags(() => TagService.ClearTags(paths))) return;
        RefreshVisibleTags();
        RefreshTagOptions();
        StatusText = $"Cleared tags on {paths.Length:N0} item{(paths.Length == 1 ? string.Empty : "s")}.";
    }

    public void DeleteTag(TagDefinition tag)
    {
        if (!TryUpdateTags(() => TagService.Delete(tag.Id))) return;
        RefreshVisibleTags();
        RefreshTagOptions();

        if (HasSearch)
            ApplySearchFilter(updateStatus: true);

        StatusText = $"Deleted the {tag.Name} tag.";
    }

    private bool TryUpdateTags(Action update)
    {
        try { update(); return true; }
        catch (InvalidOperationException exception)
        {
            // Restore a toggled checkbox from committed data after a failed write.
            try { RefreshTagOptions(); }
            catch (InvalidOperationException) { TagOptions.Clear(); }
            StatusText = exception.Message;
            return false;
        }
    }

    public void SearchByTag(TagDefinition tag)
    {
        SearchEverywhere = true;
        SearchText = $"tag:{tag.Id}";
    }

    // NEW (lock icons): re-reads the lock badge of every listed row after a lock operation.
    internal void RefreshLockBadges()
    {
        foreach (var item in _directoryItems)
            item.RefreshLock();

        if (!ReferenceEquals(Items, _directoryItems))
        {
            foreach (var item in Items)
                item.RefreshLock();
        }
    }

    private void RefreshVisibleTags()
    {
        // CHANGED (search fix): one read of the tags for the whole list (it was one per row).
        var tags = TagService.Lookup();
        foreach (var item in _directoryItems)
            item.RefreshTags(tags);

        if (!ReferenceEquals(Items, _directoryItems))
        {
            foreach (var item in Items)
                item.RefreshTags(tags);
        }
    }

    private string _currentPath = string.Empty;
    public string CurrentPath
    {
        get => _currentPath;
        private set
        {
            if (SetProperty(ref _currentPath, value))
            {
                Context.CurrentPath = value;
                OnPropertyChanged(nameof(Breadcrumbs));
                OnPropertyChanged(nameof(IsYourFilesHub));          // NEW (your files)
                OnPropertyChanged(nameof(CanRemoveFromYourFiles));  // NEW (your files)
                OnPropertyChanged(nameof(IsNetworkHub));            // NEW (map network drive)
                OnPropertyChanged(nameof(IsInArchive));             // NEW (zip folders)

                OnPropertyChanged(nameof(FolderProfileLabel));
            }
        }
    }

    private string _addressText = string.Empty;
    public string AddressText
    {
        get => _addressText;
        set => SetProperty(ref _addressText, value);
    }

    private LayoutMode _layout = LayoutMode.Details;
    public LayoutMode Layout
    {
        get => _layout;
        private set
        {
            if (SetProperty(ref _layout, value))
            {
                OnPropertyChanged(nameof(IsGrid));
                OnPropertyChanged(nameof(IsDetails));
                OnPropertyChanged(nameof(ListGrouping)); // NEW (folder types, step 2)
            }
        }
    }

    public bool IsGrid => Layout == LayoutMode.Grid;

    public bool IsDetails => Layout == LayoutMode.Details;

    // CHANGED (folder types): the folder's type is a FolderType definition (built-in or custom), possibly
    // inherited from a parent folder whose type applies to subfolders. FolderProfile is its built-in family.
    private FolderType _folderType = FolderTypes.Automatic;
    private string? _folderTypeInheritedFrom;

    public FolderType FolderType => _folderType;
    public DirectoryViewProfile FolderProfile => _folderType.Base;
    public string? FolderTypeInheritedFrom => _folderTypeInheritedFrom;

    public bool FolderTypeAppliesToSubfolders
        => CanSetFolderProfile && _folderTypeInheritedFrom is null && !_folderType.IsAutomatic &&
           SettingsService.GetFolderTypeAppliesToSubfolders(CurrentPath);

    // NEW (folder types, step 2): the type whose behaviors apply here - the effective type, or for
    // Automatic, the type detected from the folder's name and contents (Screenshots, Code, ...).
    private FolderType _resolvedType = FolderTypes.General;
    public FolderType ResolvedFolderType => _resolvedType;

    private void ApplyFolderType(FolderType type, string? inheritedFrom)
    {
        _folderType = type;
        _folderTypeInheritedFrom = inheritedFrom;
        _resolvedType = !CanSetFolderProfile
            ? FolderTypes.General
            : type.IsAutomatic ? FolderTypes.Detected(CurrentPath, lookAtContents: true) : type;

        OnPropertyChanged(nameof(FolderType));
        OnPropertyChanged(nameof(FolderProfile));
        OnPropertyChanged(nameof(FolderTypeInheritedFrom));
        OnPropertyChanged(nameof(FolderTypeAppliesToSubfolders));
        OnPropertyChanged(nameof(FolderProfileLabel));
        OnPropertyChanged(nameof(FolderTypeTooltip));
        OnPropertyChanged(nameof(IsAutomaticProfile));
        OnPropertyChanged(nameof(IsGeneralProfile));
        OnPropertyChanged(nameof(IsPhotosProfile));
        OnPropertyChanged(nameof(IsMusicProfile));
        OnPropertyChanged(nameof(ResolvedFolderType));   // NEW (step 2)
        OnPropertyChanged(nameof(ListGrouping));      // NEW (step 2)
        OnPropertyChanged(nameof(IsProjectFolder));      // NEW (step 2)
        OnPropertyChanged(nameof(ShowsProjectStrip));    // NEW (step 2)
        OnPropertyChanged(nameof(ProjectTitle));         // NEW (step 2)

        LoadColumns();
    }

    public string FolderProfileLabel => FolderTypes.Label(_folderType, CurrentPath);

    // CHANGED (folder types, step 3): says what Automatic picked and why it matters.
    public string FolderTypeTooltip => _folderTypeInheritedFrom is { } from
        ? $"Folder type: {_folderType.Name}, applied to this folder by {from}"
        : _folderType.IsAutomatic && _resolvedType.Id != FolderTypes.General.Id
            ? $"Automatic picked {_resolvedType.Name}: {_resolvedType.Description}. Choose a type to keep one."
            : "Choose a folder type for this folder";

    public bool IsAutomaticProfile => _folderType.IsAutomatic;
    public bool IsGeneralProfile => FolderProfile == DirectoryViewProfile.General;
    // CHANGED (folder types, step 3): the detected type counts too (an Automatic folder full of songs gets
    // the player), and Screenshots and Design & 3D get the photo viewer.
    public bool IsPhotosProfile => _resolvedType.PhotoViewer;
    public bool IsMusicProfile => _resolvedType.Base == DirectoryViewProfile.Music;

    // NEW (folder types, step 3): whether visible columns need file properties (title, pages, length...).
    public bool NeedsFileProperties => ColumnCatalog.NeedsFileProperties(_visibleColumns);
    public bool CanSetFolderProfile => !string.IsNullOrWhiteSpace(CurrentPath) &&
                                       !CurrentPath.StartsWith("clearspace://", StringComparison.OrdinalIgnoreCase);
    public bool HasSelectedFolders => Context.SelectedItems.Any(item => item.IsStandardFolder);

    private double _tileScale = 1;
    private bool _restoringTileScale;
    public double TileScale
    {
        get => _tileScale;
        private set
        {
            var clamped = Math.Clamp(value, 0.70, 2.20);
            if (!SetProperty(ref _tileScale, clamped)) return;
            OnPropertyChanged(nameof(TileWidth));
            OnPropertyChanged(nameof(TileHeight));
            OnPropertyChanged(nameof(TilePreviewSize));
            OnPropertyChanged(nameof(TilePreviewAreaHeight));
            OnPropertyChanged(nameof(TileZoomText));

            if (!_restoringTileScale && !string.IsNullOrWhiteSpace(CurrentPath))
                SettingsService.SetFolderTileScale(CurrentPath, clamped);
        }
    }

    public double TileWidth => Math.Ceiling(132 * TileScale);
    public double TilePreviewSize => Math.Ceiling(104 * TileScale);
    public double TilePreviewAreaHeight => Math.Max(118, TilePreviewSize + 14);
    public double TileHeight => Math.Ceiling(TilePreviewAreaHeight + 104);
    public string TileZoomText => $"{TileScale * 100:N0}%";

    public void AdjustTileScale(double delta) => TileScale += delta;

    private void RestoreTileScale(string path)
    {
        _restoringTileScale = true;
        try
        {
            // CHANGED (folder types, step 2): the type's starting size when the folder has none of its own.
            TileScale = SettingsService.GetFolderTileScale(path) ?? _resolvedType.TileScale ?? 1;
        }
        finally
        {
            _restoringTileScale = false;
        }
    }

    private const int GridItemLimit = 3000;

    public void SetLayout(LayoutMode layout)
    {
        if (layout == LayoutMode.Grid && Items.Count > GridItemLimit)
        {
            StatusText = $"Too many items for tiles ({Items.Count:N0}). Staying in details.";
            return;
        }

        if (Layout == layout)
            return;

        Layout = layout;

        if (layout == LayoutMode.Details)
            _ = EnsureItemIconsAsync();

        if (!string.IsNullOrEmpty(CurrentPath))
            SettingsService.SetFolderLayout(CurrentPath, layout.ToString());
    }

    public void ToggleLayout()
        => SetLayout(Layout == LayoutMode.Details ? LayoutMode.Grid : LayoutMode.Details);

    public void SetFolderProfile(DirectoryViewProfile profile) => SetFolderType(FolderTypes.ForProfile(profile));

    // CHANGED (folder types): any type, built-in or custom. Its layout comes from the definition.
    public void SetFolderType(FolderType type)
    {
        if (!CanSetFolderProfile)
            return;

        SettingsService.SetFolderViewProfile(CurrentPath, type.Id);
        if (!type.IsAutomatic)
            SettingsService.SetFolderTypeAppliesToSubfolders([CurrentPath], type.SubfoldersByDefault);

        // Automatic may now pick up a parent's type, so resolve rather than assume.
        RestoreFolderProfile(CurrentPath);

        var preferredLayout = !_folderType.IsAutomatic && _folderType.Layout is { } typed
            ? typed
            : ResolveLayout(CurrentPath, Items);

        if (preferredLayout == LayoutMode.Grid && Items.Count > GridItemLimit)
            preferredLayout = LayoutMode.Details;

        Layout = preferredLayout;
        if (Layout == LayoutMode.Details)
            _ = EnsureItemIconsAsync();

        // NEW (folder types, step 2): the new type's sort, tile size, dimming, Git and project strip.
        RestoreTileScale(CurrentPath);
        if (ApplyTypeSort())
            ResortDirectoryItems();
        MarkGenerated(_directoryItems);
        _ = RefreshFolderExtrasAsync(CurrentPath);
    }

    // NEW (folder types): whether this folder's type also applies to the folders below it.
    public void SetFolderTypeAppliesToSubfolders(bool applies)
    {
        if (!CanSetFolderProfile || FolderTypes.AssignedTo(CurrentPath).IsAutomatic)
            return;

        SettingsService.SetFolderTypeAppliesToSubfolders([CurrentPath], applies);
        OnPropertyChanged(nameof(FolderTypeAppliesToSubfolders));
        StatusText = applies
            ? $"{_folderType.Name} now applies to every folder inside this one (unless a folder has its own type)."
            : $"{_folderType.Name} now applies to this folder only.";
    }

    // NEW (folder types): save the current layout and columns as a custom type, and apply it here.
    public void SaveViewAsFolderType(string name)
    {
        name = name.Trim();
        if (!CanSetFolderProfile || name.Length == 0)
            return;

        var existing = FolderTypes.Find(name);
        if (existing is { IsCustom: false })
        {
            StatusText = $"\"{name}\" is a built-in folder type. Choose another name.";
            return;
        }

        var basis = FolderTypes.Resolved(CurrentPath);
        var data = new CustomFolderTypeData
        {
            Id = existing?.Id ?? FolderTypes.NewCustomId(name),
            Name = name,
            Base = (basis.Base == DirectoryViewProfile.Automatic ? DirectoryViewProfile.General : basis.Base).ToString(),
            Layout = Layout.ToString(),
            Columns = [.. _visibleColumns],
            Subfolders = true,
            // NEW (folder types, step 2): the sort and tile size are part of the saved view too.
            Sort = SortColumn.ToString(),
            SortDescending = SortDescending,
            TileScale = Math.Abs(TileScale - 1) < 0.01 ? null : TileScale
        };

        SettingsService.SaveCustomFolderType(data);
        SetFolderType(FolderTypes.FromData(data));
        StatusText = existing is null
            ? $"Saved \"{name}\" as a folder type and applied it here and to subfolders."
            : $"Updated the \"{name}\" folder type.";
    }

    // NEW (folder types): remove a custom type; folders using it go back to Automatic.
    public void DeleteFolderType(FolderType type)
    {
        if (!type.IsCustom)
            return;

        SettingsService.DeleteCustomFolderType(type.Id);
        if (!string.IsNullOrWhiteSpace(CurrentPath))
        {
            RestoreFolderProfile(CurrentPath);
            Layout = ResolveLayout(CurrentPath, Items);
        }

        StatusText = $"Deleted the \"{type.Name}\" folder type.";
    }

    public void SetFolderProfilesForSelection(DirectoryViewProfile profile) => SetFolderTypeForSelection(FolderTypes.ForProfile(profile));

    public void SetFolderTypeForSelection(FolderType type)
    {
        var folders = Context.SelectedItems
            .Where(item => item.IsStandardFolder)
            .Select(item => item.FullPath)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        if (folders.Length == 0)
        {
            StatusText = "Select one or more folders to set their folder type.";
            return;
        }

        SettingsService.SetFolderViewProfiles(folders, type.Id);
        if (!type.IsAutomatic)
            SettingsService.SetFolderTypeAppliesToSubfolders(folders, type.SubfoldersByDefault); // NEW

        foreach (var item in Context.SelectedItems.Where(item => item.IsStandardFolder))
        {
            item.Thumbnail = null;
            item.GridPlaceholder = null;
            item.Icon = IconService.GetIcon(item);
        }

        var folderLabel = folders.Length == 1 ? "folder" : "folders";
        var typeLabel = type.IsAutomatic ? "automatic" : type.Name;
        StatusText = $"Set {typeLabel} view for {folders.Length:N0} {folderLabel}.";
    }


    private DateTime _lastIndexReport = DateTime.MinValue;

    private void OnFileIndexChanged(object? sender, EventArgs e)
    {
        var now = DateTime.UtcNow;

        if (FileIndexService.IsBuilding && now - _lastIndexReport < TimeSpan.FromMilliseconds(400))
            return;

        _lastIndexReport = now;

        var dispatcher = Application.Current?.Dispatcher;

        if (dispatcher is null)
            return;

        dispatcher.BeginInvoke(DispatcherPriority.Background, () =>
        {
            OnPropertyChanged(nameof(IndexStatusText));
            OnPropertyChanged(nameof(IndexTooltip));
        });
    }

    public string IndexStatusText
    {
        get
        {
            var status = FileIndexService.Status;
            return status.Length > 0 ? status : "Index starting…";
        }
    }

    public string IndexTooltip
    {
        get
        {
            var lines = new List<string>
            {
                $"Clearspace {BuildVersion}  ·  built {BuildStamp}",
                string.Empty,
                $"{FileIndexService.Count:N0} items  ·  about {FileSystemItem.FormatSize(FileIndexService.EstimatedBytes)} in memory"
            };

            foreach (var skipped in FileIndexService.SkippedRoots)
                lines.Add($"{skipped} too large to index — searched by crawling");

            lines.Add(string.Empty);
            lines.Add(FileIndexStore.FilePath);

            return string.Join(Environment.NewLine, lines);
        }
    }

    public static string BuildStamp
    {
        get
        {
            try
            {
                var path = Environment.ProcessPath;

                return string.IsNullOrEmpty(path) || !File.Exists(path)
                    ? "unknown"
                    : File.GetLastWriteTime(path).ToString("yyyy-MM-dd HH:mm:ss");
            }
            catch (Exception)
            {
                return "unknown";
            }
        }
    }

    public static string BuildVersion =>
        System.Reflection.Assembly.GetEntryAssembly()?.GetName().Version?.ToString() ?? "1.0.0";

    private string _statusText = "Ready";
    internal void ReportFileLock(string message) => StatusText = message;

    // NEW (archives): the same, for anything else the window wants to say in the status bar ("Made Photos.zip.").
    internal void ReportStatus(string message) => StatusText = message;

    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }

    private string _timingText = string.Empty;
    public string TimingText
    {
        get => _timingText;
        private set
        {
            if (SetProperty(ref _timingText, value))
                OnPropertyChanged(nameof(HasTiming));
        }
    }

    public bool HasTiming => !string.IsNullOrEmpty(TimingText);

    private string _hubTitle = string.Empty;
    public string HubTitle
    {
        get => _hubTitle;
        private set => SetProperty(ref _hubTitle, value);
    }

    private string _hubSummary = string.Empty;
    public string HubSummary
    {
        get => _hubSummary;
        private set => SetProperty(ref _hubSummary, value);
    }

    private string _hubDescription = string.Empty;
    public string HubDescription
    {
        get => _hubDescription;
        private set => SetProperty(ref _hubDescription, value);
    }

    public bool IsHub => !string.IsNullOrEmpty(HubTitle);

    private bool _isLoading;
    public bool IsLoading
    {
        get => _isLoading;
        private set => SetProperty(ref _isLoading, value);
    }

    private bool _useWindowsIndex;
    public bool UseWindowsIndex
    {
        get => _useWindowsIndex;
        set
        {
            if (!SetProperty(ref _useWindowsIndex, value))
                return;

            SettingsService.SetUseWindowsIndex(value);

            if (HasSearch)
                ApplySearchFilter(updateStatus: true);
        }
    }

    public bool IsWindowsIndexAvailable => WindowsSearchService.IsAvailable;

    public void OpenIndexingOptions()
    {
        if (!WindowsSearchService.OpenIndexingOptions())
            StatusText = "Could not open Windows indexing options.";
    }

    private bool _searchFileContents;

    public bool SearchFileContents
    {
        get => _searchFileContents;
        set
        {
            if (!SetProperty(ref _searchFileContents, value))
                return;

            SettingsService.SetSearchFileContents(value);

            if (HasSearch)
                ApplySearchFilter(updateStatus: true);
        }
    }

    private bool _showHiddenItems;
    public bool ShowHiddenItems
    {
        get => _showHiddenItems;
        set
        {
            if (!SetProperty(ref _showHiddenItems, value))
                return;

            SettingsService.SetShowHiddenItems(value);
            _ = RefreshAsync();
        }
    }

    private SortColumn _sortColumn = SortColumn.Name;
    public SortColumn SortColumn
    {
        get => _sortColumn;
        private set => SetProperty(ref _sortColumn, value);
    }

    private bool _sortDescending;
    public bool SortDescending
    {
        get => _sortDescending;
        private set => SetProperty(ref _sortDescending, value);
    }

    public IReadOnlyList<Breadcrumb> Breadcrumbs => BuildBreadcrumbs(CurrentPath);


    private bool _isCloudFolder;

    public bool IsCloudFolder
    {
        get => _isCloudFolder;
        private set => SetProperty(ref _isCloudFolder, value);
    }

    private string _cloudRootName = string.Empty;

    public string CloudRootName
    {
        get => _cloudRootName;
        private set => SetProperty(ref _cloudRootName, value);
    }

    private string? _accessDeniedPath;

    public string? AccessDeniedPath
    {
        get => _accessDeniedPath;
        private set
        {
            if (SetProperty(ref _accessDeniedPath, value))
            {
                OnPropertyChanged(nameof(IsAccessDenied));
                OnPropertyChanged(nameof(CanRetryElevated));
            }
        }
    }

    public bool IsAccessDenied => _accessDeniedPath is not null;

    public bool CanRetryElevated => IsAccessDenied && !ElevationService.IsElevated;

    public string WindowTitle => ElevationService.IsElevated
        ? "Clearspace \u00b7 Administrator"
        : "Clearspace";

    public void OpenCurrentElevated()
    {
        var target = AccessDeniedPath ?? CurrentPath;

        if (string.IsNullOrWhiteSpace(target))
            return;

        if (!ElevationService.TryRelaunchAt(target, out var message) && message is not null)
            StatusText = message;
    }


    public bool HasCloudSelection => Context.SelectedItems.Any(item => item.IsCloudItem);

    public async Task SetCloudPinStateAsync(bool pinned)
    {
        var targets = Context.SelectedItems
            .Where(item => item.IsCloudItem)
            .Select(item => item.FullPath)
            .ToArray();

        if (targets.Length == 0)
            return;

        StatusText = pinned ? "Keeping on this device\u2026" : "Freeing up space\u2026";

        try
        {
            await Task.Run(() =>
            {
                foreach (var target in targets)
                    CloudStorageService.SetPinned(target, pinned);
            });
        }
        catch (Exception exception)
        {
            StatusText = exception.Message;
            return;
        }

        await RefreshAsync();

        var noun = targets.Length == 1 ? "item" : "items";
        StatusText = pinned
            ? $"{targets.Length:N0} {noun} will be kept on this device"
            : $"{targets.Length:N0} {noun} released to the cloud";
    }

    public void Start(string? initialPath = null)
    {
        // NEW (zip folders): a window can start inside a ZIP file (Clearspace.exe "C:\Downloads\Photos.zip").
        if (!string.IsNullOrWhiteSpace(initialPath) &&
            !initialPath.StartsWith("clearspace://", StringComparison.OrdinalIgnoreCase) &&
            ArchiveLocation.FromTyped(initialPath) is { } insideZip)
        {
            initialPath = insideZip;
        }

        // CHANGED (new window): a window can also start on one of Clearspace's own pages (This PC, a hub),
        // which is where Ctrl+N from such a page opens the new window.
        var start = !string.IsNullOrWhiteSpace(initialPath) &&
                    (Directory.Exists(initialPath) || initialPath.StartsWith("clearspace://", StringComparison.OrdinalIgnoreCase))
            ? initialPath
            : KnownFolders.Profile;

        // NEW (tab to new window): a window made for a tab that was moved out of another one is already
        // somewhere (its history came with it). Show that place; initialPath does not apply.
        if (Navigation.CurrentPath is { } resumed)
            start = resumed;

        Navigation.Navigate(start);

        _ = SidebarState.LoadDrivesAsync();

        FileIndexService.Start();
        DiskUsageSnapshotCache.Start(); // NEW (round 19): keep disk-map sizes warm so the view opens instantly
    }

    public Task RefreshAsync() => LoadAsync(CurrentPath, force: true);

    public void Sort(SortColumn column)
    {
        SortDescending = column == SortColumn && !SortDescending;
        SortColumn = column;

        // NEW (folder types, step 2): a sort you choose becomes your usual sort, unless this folder's
        // type sets its own (then it lasts for this visit).
        if (!_typeSortActive)
        {
            _userSortColumn = SortColumn;
            _userSortDescending = SortDescending;
        }

        ResortDirectoryItems();
    }

    private void ResortDirectoryItems()
    {
        var sorted = _directoryItems.ToList();
        _sortedFoldersFirst = FoldersFirst; // CHANGED (date order)
        sorted.Sort(new ItemComparer(SortColumn, SortDescending, _sortedFoldersFirst));
        SetDirectoryItems(sorted);
        if (!string.IsNullOrWhiteSpace(CurrentPath))
            FolderSnapshotCache.Set(CurrentPath, sorted);
        OnPropertyChanged(nameof(ListGrouping));
    }

    // ------------------------------------------------------------------ NEW (folder types, step 2)

    private SortColumn _userSortColumn = SortColumn.Name;
    private bool _userSortDescending;
    private bool _typeSortActive;

    // Applies the resolved type's sort, or goes back to your usual sort. True when the sort changed.
    private bool ApplyTypeSort()
    {
        var (column, descending) = (SortColumn, SortDescending);

        if (_resolvedType.Sort is { } typed)
        {
            SortColumn = typed;
            SortDescending = _resolvedType.SortDescending;
            _typeSortActive = true;
        }
        else if (_typeSortActive)
        {
            SortColumn = _userSortColumn;
            SortDescending = _userSortDescending;
            _typeSortActive = false;
        }

        OnPropertyChanged(nameof(ListGrouping));
        // CHANGED (date order): also when only "folders first" changes (a date-sorted General folder
        // becoming a Downloads folder keeps its column and direction but mixes folders in).
        return column != SortColumn || descending != SortDescending || _sortedFoldersFirst != FoldersFirst;
    }

    // ------------------------------------------------------------------ NEW (date order)
    // Folders are listed before files, whatever the sort. That is wrong for the one kind of list whose
    // point is "what arrived last": a folder type that sorts by date and groups by day (Downloads,
    // Screenshots, Archives & Backups). There, 400 old folders stood in front of today's download, and the
    // "Today" group came after every group a folder belonged to. In those lists folders and files are
    // sorted together, so the newest thing is first, whatever it is. Sorting such a folder by another
    // column (Name, Size ...) puts folders first again, as everywhere else.
    private bool FoldersFirst => !(_resolvedType.Grouping == FolderGrouping.Date && SortColumn == SortColumn.DateModified);

    // How the list on screen was sorted, so a row renamed or merged in later lands by the same rule.
    private bool _sortedFoldersFirst = true;

    // NEW (folder types, step 3): re-resolve an Automatic folder after its contents were seen.
    private void ReapplyDetectedType(string path)
    {
        // Windows' folders, names and repositories were already known; only reapply when the answer moved.
        if (FolderTypes.Detected(path, lookAtContents: true).Id == _resolvedType.Id)
            return;

        RestoreFolderProfile(path);

        RestoreTileScale(path);
        if (ApplyTypeSort())
            ResortDirectoryItems();
        else
            SetDirectoryItems(_directoryItems);

        Layout = ResolveLayout(path, _directoryItems);
        if (Layout == LayoutMode.Details)
            _ = EnsureItemIconsAsync();
    }

    // Screenshots: details view grouped under Today / Yesterday / ... while sorted by date.
    // CHANGED (folder types, step 3): the item property the details view groups by, or null.
    // Date groups (Screenshots, Downloads, Archives) only while sorted by date; Kind groups (Desktop) always.
    public string? ListGrouping
    {
        get
        {
            if (!IsDetails || HasSearch)
                return null;

            return _resolvedType.Grouping switch
            {
                FolderGrouping.Date when SortColumn == SortColumn.DateModified => nameof(FileSystemItem.DateGroup),
                FolderGrouping.Kind => nameof(FileSystemItem.KindGroup),
                _ => null
            };
        }
    }

    // Code: build output and dependency folders are dimmed.
    private void MarkGenerated(IReadOnlyList<FileSystemItem> items)
    {
        var dim = _resolvedType.DimGenerated;

        for (var i = 0; i < items.Count; i++)
            items[i].IsGenerated = dim && items[i].IsFolder && GeneratedFolders.IsGenerated(items[i].Name);
    }

    // Code: "git: main · 3 changed" beside the folder type button.
    private string _folderContextText = string.Empty;
    public string FolderContextText
    {
        get => _folderContextText;
        private set
        {
            if (SetProperty(ref _folderContextText, value))
                OnPropertyChanged(nameof(HasFolderContext));
        }
    }

    public bool HasFolderContext => _folderContextText.Length > 0;

    // Projects: the folder the Projects type is assigned to (this one, or the one it is inherited from).
    public bool IsProjectFolder => _resolvedType.ShowProjectStrip && CanSetFolderProfile;
    public bool ShowsProjectStrip => IsProjectFolder && !HasSearch;

    // NEW (downloads): a folder whose type is Downloads (or a type of your own based on it) gets the "Just
    // arrived" strip, learned filing and the installers list. See MainWindow.Downloads.cs.
    public bool IsDownloadsFolder => _resolvedType.Base == DirectoryViewProfile.Downloads && CanSetFolderProfile;
    public bool ShowsJustArrived => IsDownloadsFolder && !HasSearch && !IsAccessDenied;
    public string? ProjectRoot => IsProjectFolder ? _folderTypeInheritedFrom ?? CurrentPath : null;
    public string ProjectTitle => ProjectRoot is { } root ? Path.GetFileName(root.TrimEnd('\\')) : string.Empty;

    public ObservableCollection<ProjectStripItem> ProjectStrip { get; } = [];

    private string _projectStripHint = string.Empty;
    public string ProjectStripHint
    {
        get => _projectStripHint;
        private set => SetProperty(ref _projectStripHint, value);
    }

    private CancellationTokenSource? _extrasCancel;

    // Git status (Code) and the project strip (Projects), read in the background after a folder opens.
    private async Task RefreshFolderExtrasAsync(string path)
    {
        _extrasCancel?.Cancel();
        _extrasCancel = new CancellationTokenSource();
        var token = _extrasCancel.Token;

        var wantsGit = _resolvedType.Base == DirectoryViewProfile.Code && CanSetFolderProfile;
        var projectRoot = ProjectRoot;

        if (!wantsGit)
        {
            FolderContextText = string.Empty;
            GitService.Apply(null, _directoryItems);
        }

        if (projectRoot is null)
            ProjectStrip.Clear();

        try
        {
            if (projectRoot is not null)
            {
                var pins = SettingsService.GetProjectPins(projectRoot);
                var strip = await Task.Run(() => ProjectFiles.Build(projectRoot, pins, 8, token), token);

                if (token.IsCancellationRequested || !path.Equals(CurrentPath, StringComparison.OrdinalIgnoreCase))
                    return;

                ProjectStrip.Clear();
                foreach (var item in strip)
                    ProjectStrip.Add(item);

                ProjectStripHint = strip.Count == 0
                    ? "Nothing here yet. Right-click a file and choose Pin to project."
                    : string.Empty;
            }

            if (wantsGit)
            {
                var snapshot = await GitService.ReadAsync(path, token);

                if (token.IsCancellationRequested || !path.Equals(CurrentPath, StringComparison.OrdinalIgnoreCase))
                    return;

                GitService.Apply(snapshot, _directoryItems);
                FolderContextText = snapshot is null ? string.Empty : GitService.Describe(snapshot);
            }
        }
        catch (OperationCanceledException)
        {
        }
    }

    public bool CanPinToProject => IsProjectFolder && Context.SelectedItems.Count > 0;

    public void PinSelectionToProject(bool pin)
    {
        if (ProjectRoot is not { } root)
            return;

        var paths = Context.SelectedItems.Select(item => item.FullPath).ToArray();
        if (paths.Length == 0)
            return;

        SettingsService.SetProjectPins(root, paths, pin);
        _ = RefreshFolderExtrasAsync(CurrentPath);

        var count = paths.Length == 1 ? "1 item" : $"{paths.Length:N0} items";
        StatusText = pin ? $"Pinned {count} to {ProjectTitle}." : $"Unpinned {count} from {ProjectTitle}.";
    }

    public void UnpinFromProject(ProjectStripItem item)
    {
        if (ProjectRoot is not { } root)
            return;

        SettingsService.SetProjectPins(root, [item.FullPath], pinned: false);
        _ = RefreshFolderExtrasAsync(CurrentPath);
    }

    public void OpenProjectItem(ProjectStripItem item)
    {
        if (item.IsFolder)
        {
            Navigation.Navigate(item.FullPath);
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo { FileName = item.FullPath, UseShellExecute = true });
        }
        catch (Exception exception)
        {
            StatusText = $"Could not open {item.Name}: {exception.Message}";
        }
    }

    public void ShowProjectItemInFolder(ProjectStripItem item)
    {
        var folder = Path.GetDirectoryName(item.FullPath);
        if (!string.IsNullOrEmpty(folder))
            Navigation.Navigate(folder);
    }

    // ------------------------------------------------------------------ NEW (your files)
    // The Your files page shows Windows' six folders and, after them, folders you added yourself
    // (Services/LibraryFolders.cs). "New folder" there makes one in your user folder, next to Documents
    // and the rest; the window does that (it owns the renaming box) and reports it here.

    public bool IsYourFilesHub => CurrentPath.Equals(YourFilesPath, StringComparison.OrdinalIgnoreCase);

    // NEW (map network drive): the Network page has a "Map network drive…" button in its banner, and the
    // empty part of the This PC and Network pages has a menu with the same entry (MainWindow.NetworkDrives.cs).
    public bool IsNetworkHub => CurrentPath.Equals(NetworkPath, StringComparison.OrdinalIgnoreCase);
    public bool IsDrivesPage => IsNetworkHub || CurrentPath.Equals(MyPcPath, StringComparison.OrdinalIgnoreCase);

    // Where a new folder of yours is made: the user folder, where Windows keeps the six by default.
    public static string LibraryRoot => KnownFolders.Profile;

    public void AddLibraryFolder(string path)
    {
        // One of Windows' six, or a folder you added before, is already on the page.
        var listed = LocationCatalog.BuildUserFileEntries().Any(entry => string.Equals(
            Path.TrimEndingDirectorySeparator(entry.Path), Path.TrimEndingDirectorySeparator(path), StringComparison.OrdinalIgnoreCase));

        if (listed)
        {
            StatusText = $"{LibraryFolders.NameOf(path)} is already in Your files.";
            return;
        }

        SidebarState.AddLibraryFolder(path);
        StatusText = $"Added {LibraryFolders.NameOf(path)} to Your files.";
    }

    // True when everything selected on the Your files page is a folder you added (the six stay put).
    public bool CanRemoveFromYourFiles
        => IsYourFilesHub && Context.SelectedItems.Count > 0 &&
           Context.SelectedItems.All(item => SettingsService.IsLibraryFolder(item.FullPath));

    // Takes the selected folders off the Your files page. The folders themselves are not touched.
    public async Task RemoveSelectionFromYourFilesAsync()
    {
        if (!CanRemoveFromYourFiles)
            return;

        var paths = Context.SelectedPaths;
        foreach (var path in paths)
            SidebarState.RemoveLibraryFolder(path);

        await RefreshAsync();
        StatusText = paths.Length == 1
            ? $"Removed {LibraryFolders.NameOf(paths[0])} from Your files. The folder itself is still in {Path.GetDirectoryName(paths[0])}."
            : $"Removed {paths.Length:N0} folders from Your files. The folders themselves were not deleted.";
    }

    public void RemoveLibraryFolder(string path)
    {
        SidebarState.RemoveLibraryFolder(path);
        if (IsYourFilesHub)
            _ = RefreshAsync();
    }

    public void ApplyRename(FileSystemItem item, string newFullPath)
    {
        SidebarState.RenameLibraryFolder(item.FullPath, newFullPath); // NEW (your files): a folder of yours keeps its place

        var index = -1;
        for (var i = 0; i < _directoryItems.Count; i++)
        {
            if (ReferenceEquals(_directoryItems[i], item))
            {
                index = i;
                break;
            }
        }

        if (index < 0)
        {
            _ = RefreshAsync();
            return;
        }

        // CHANGED (pre-release review): was MovePath. MovePaths also carries the tags of everything inside a
        // renamed folder to its new place; they used to be left behind under the old name.
        TagService.MovePaths([(item.FullPath, newFullPath)]);
        item.ApplyRename(newFullPath);

        var reordered = _directoryItems.ToList();
        reordered.RemoveAt(index);

        var comparer = new ItemComparer(SortColumn, SortDescending, _sortedFoldersFirst); // CHANGED (date order)
        // CHANGED (your files): a hub's list is in its own order (Windows' six, then yours), not sorted,
        // so a renamed entry stays where it is there instead of jumping to its alphabetical place.
        var insertAt = IsHub ? index : reordered.FindIndex(existing => comparer.Compare(item, existing) < 0);
        if (insertAt < 0)
            insertAt = reordered.Count;

        reordered.Insert(insertAt, item);

        SetDirectoryItems(reordered);
        if (!string.IsNullOrWhiteSpace(CurrentPath))
            FolderSnapshotCache.Set(CurrentPath, reordered);

        UpdateStatus();
    }

    // NEW (batch rename): several items were renamed on disk by the batch rename dialog. Their tags and
    // their places in Your files follow them, as in ApplyRename, and the folder is read again (many rows
    // moved, so splicing each one into place would be more work than a fresh listing).
    public async Task ApplyBatchRenameAsync(IReadOnlyList<(string From, string To)> renamed)
    {
        if (renamed.Count == 0)
            return;

        var tagsFollowed = true;
        try
        {
            foreach (var (from, to) in renamed)
                SidebarState.RenameLibraryFolder(from, to);

            // FIXED (pre-release review): one call for the whole batch (was MovePath for each item). Done
            // one at a time, a batch whose names shift along (1, 2, 3 becoming 2, 3, 4) or swap piled every
            // item's tags onto the next one. It is also one database transaction instead of one per item.
            TagService.MovePaths(renamed);
        }
        catch (Exception)
        {
            tagsFollowed = false; // the files are renamed either way; say so below rather than stop here
        }

        await RefreshAsync();
        var count = renamed.Count == 1 ? "1 item" : $"{renamed.Count:N0} items";
        StatusText = tagsFollowed ? $"Renamed {count}." : $"Renamed {count}, but their tags could not be carried over.";
    }

    // ------------------------------------------------------------------ NEW (live folder)
    // The folder on screen is watched (Services/FolderWatcher.cs). When another program adds, removes,
    // renames or changes something in it, the folder is read again in the background and the difference
    // is merged into the list (Services/FolderMerge.cs): rows that did not change stay the same objects,
    // so the selection, the scroll position and the tile pictures are left alone.
    //  - Only real folders are watched, and only the one this window is showing. A tab in the background
    //    is read again anyway when you come back to it.
    //  - While a search is showing, the list is search results, not the folder; the change is remembered
    //    and merged when the search is cleared.
    //  - A change that arrives during a load waits for the load to finish (the watcher is asked to call again).
    private readonly FolderWatcher _folderWatcher;
    private CancellationTokenSource? _mergeCancel;
    private long _watchOrder;
    private bool _merging;
    private bool _changedWhileMerging;
    private bool _changedDuringSearch;
    private bool _liveFolderClosed;

    private void WatchFolderOnScreen(string path)
    {
        _mergeCancel?.Cancel();     // a merge in progress was for the list being replaced
        _changedDuringSearch = false;

        var folder = Path.IsPathFullyQualified(path) ? path : null; // not This PC, a hub or another page
        var order = ++_watchOrder;
        // Off the UI thread: starting a watch on a network folder that is slow to answer must not hold
        // the window up. `order` keeps a slow start for an earlier folder from replacing a later one.
        _ = Task.Run(() => _folderWatcher.Watch(folder, order));
    }

    // Called on the UI thread, a moment after the folder on screen changed on the disk.
    private void OnFolderChangedOnDisk()
    {
        if (_liveFolderClosed)
            return;

        if (HasSearch)
        {
            _changedDuringSearch = true;
            return;
        }

        if (IsLoading)
        {
            _folderWatcher.Nudge(); // the load may have read the folder before this change; look again after it
            return;
        }

        if (_merging)
        {
            _changedWhileMerging = true;
            return;
        }

        _ = MergeFolderChangesAsync();
    }

    private async Task MergeFolderChangesAsync()
    {
        _merging = true;
        _changedDuringSearch = false;
        try
        {
            do
            {
                _changedWhileMerging = false;

                var path = CurrentPath;
                var current = _directoryItems;
                if (!Path.IsPathFullyQualified(path))
                    return;

                var cancel = new CancellationTokenSource();
                _mergeCancel = cancel;
                var options = new FolderLoadOptions(ShowHiddenItems, SortColumn, SortDescending,
                    ResolveLayout(path, []) == LayoutMode.Grid, ShowPartial: false, _sortedFoldersFirst);

                FolderChanges changes;
                try
                {
                    changes = await _navigationLoads.ReadChangesAsync(path, current, options, cancel.Token);
                }
                catch (OperationCanceledException)
                {
                    return; // the window moved on to another folder, or closed
                }
                catch (DirectoryNotFoundException)
                {
                    // The folder itself was deleted or renamed by another program: load it the ordinary
                    // way, which says so ("That folder no longer exists").
                    if (!_liveFolderClosed && !IsLoading && path.Equals(CurrentPath, StringComparison.OrdinalIgnoreCase))
                        await RefreshAsync();
                    return;
                }
                catch (Exception error) when (error is IOException or UnauthorizedAccessException)
                {
                    return; // could not be read just now; the list stays as it is until the next change or F5
                }

                if (_liveFolderClosed || IsLoading || !path.Equals(CurrentPath, StringComparison.OrdinalIgnoreCase))
                    return; // a load took over; it reads the folder itself

                if (HasSearch)
                {
                    _changedDuringSearch = true;
                    return;
                }

                // The list was sorted, or a row renamed, while the folder was being read: compare again.
                if (!ReferenceEquals(current, _directoryItems))
                {
                    _changedWhileMerging = true;
                    continue;
                }

                if (!changes.Any)
                    continue;

                SetDirectoryItems(changes.Items);
                FolderSnapshotCache.Set(path, changes.Items);

                if (Context.SelectedItems.Count == 0)
                    StatusText = SearchCoordinator.DescribeBrowsing(path, changes.Items);

                // Git status and the project strip are per row or per folder; the new rows need theirs.
                if ((_resolvedType.Base == DirectoryViewProfile.Code && CanSetFolderProfile) || ProjectRoot is not null)
                    _ = RefreshFolderExtrasAsync(path);
            }
            while (_changedWhileMerging);
        }
        finally
        {
            _merging = false;

            // Windows drops a watch when it loses track or the folder goes away for a moment; start it again.
            if (!_liveFolderClosed && !_folderWatcher.IsWatching && Path.IsPathFullyQualified(CurrentPath))
            {
                var folder = CurrentPath;
                var order = _watchOrder;
                _ = Task.Run(() => _folderWatcher.Watch(folder, order));
            }
        }
    }

    private void SetDirectoryItems(IReadOnlyList<FileSystemItem> items)
    {
        MarkGenerated(items); // NEW (folder types, step 2)

        // NEW (folder types, step 3): Desktop groups folders, shortcuts and files; keep each group together
        // (stable, so the sort inside each group is unchanged).
        if (_resolvedType.Grouping == FolderGrouping.Kind && items.Count > 1)
            items = [.. items.OrderBy(item => item.KindRank)];

        _directoryItems = items;
        ApplySearchFilter(updateStatus: false);
    }

    private void ApplySearchFilter(bool updateStatus)
        => _ = _search.SearchAsync(new SearchRequest(SearchText, CurrentPath, SearchEverywhere,
            ShowHiddenItems, UseWindowsIndex, SearchFileContents), _directoryItems, updateStatus);

    private void CancelTreeSearch()
    {
        _search.Cancel();
        IsSearchingTree = false;
    }

    private bool _isSearchingTree;
    public bool IsSearchingTree
    {
        get => _isSearchingTree;
        private set => SetProperty(ref _isSearchingTree, value);
    }

    private void UpdateSearchStatus()
    {
        if (HasSearch)
            StatusText = SearchCoordinator.DescribeLocal(SearchQuery.Parse(SearchText), SearchEverywhere, Items.Count);
    }

    private async Task LoadAsync(string path, bool force = false)
    {
        if (string.IsNullOrWhiteSpace(path))
            return;

        var navigationTimer = Stopwatch.StartNew();
        var keepCurrentItems = force &&
                               path.Equals(CurrentPath, StringComparison.OrdinalIgnoreCase) &&
                               _directoryItems.Count > 0;
        IReadOnlyList<FileSystemItem> snapshot = [];
        var hasSnapshot = !force && FolderSnapshotCache.TryGet(path, out snapshot);
        long? readyMilliseconds = null;

        using var load = _navigationLoads.BeginLoad();
        var token = load.Token;

        ThumbnailService.CancelPending();
        MediaPropertyService.CancelPending();

        CancelTreeSearch();

        if (!path.Equals(CurrentPath, StringComparison.OrdinalIgnoreCase))
        {
            Viewer.Close();
            if (HasSearch)
                SearchText = string.Empty;
        }

        CurrentPath = path;
        WatchFolderOnScreen(path); // NEW (live folder): the listing follows changes other programs make here
        RestoreFolderProfile(path);
        RestoreTileScale(path);
        ApplyTypeSort();                       // NEW (folder types, step 2): before the load captures the sort
        FolderContextText = string.Empty;      // NEW (folder types, step 2)

        var cloudRoot = CloudStorageService.RootFor(path);
        IsCloudFolder = cloudRoot is not null;
        CloudRootName = cloudRoot?.Name ?? string.Empty;
        AccessDeniedPath = null;

        LoadColumns();
        AddressText = ArchiveLocation.Display(path); // CHANGED (zip folders): inside a ZIP, the address written like a path
        IsLoading = true;
        StatusText = hasSnapshot ? "Refreshing cached view…" : "Opening…";
        TimingText = string.Empty;
        ClearHubInfo();

        if (hasSnapshot)
        {
            SetDirectoryItems(snapshot);
            Layout = ResolveLayout(path, snapshot);
            readyMilliseconds = navigationTimer.ElapsedMilliseconds;
            TimingText = $"{readyMilliseconds} ms open · refreshing";
        }
        else if (!keepCurrentItems)
        {
            SetDirectoryItems([]);
            Layout = ResolveLayout(path, []);
        }

        var stopwatch = navigationTimer;

        try
        {
            if (path.Equals(MyPcPath, StringComparison.OrdinalIgnoreCase) ||
                path.Equals(NetworkPath, StringComparison.OrdinalIgnoreCase))
            {
                await LoadVirtualDrivesAsync(path, stopwatch, token);
                return;
            }

            if (path.Equals(YourFilesPath, StringComparison.OrdinalIgnoreCase) ||
                path.Equals(PinnedPath, StringComparison.OrdinalIgnoreCase) ||
                path.Equals(CloudPath, StringComparison.OrdinalIgnoreCase) ||
                path.StartsWith(CategoryPathPrefix, StringComparison.OrdinalIgnoreCase))
            {
                await LoadHubAsync(path, stopwatch, token);
                return;
            }

            // NEW (zip folders): a place inside a ZIP file.
            if (ArchiveLocation.Is(path))
            {
                await LoadArchiveAsync(path, stopwatch, token);
                return;
            }

            var showHidden = ShowHiddenItems;
            var column = SortColumn;
            var descending = SortDescending;
            var foldersFirst = _sortedFoldersFirst = FoldersFirst; // NEW (date order)
            var gridFastPath = ResolveLayout(path, []) == LayoutMode.Grid;
            var showPartial = !hasSnapshot && !keepCurrentItems;
            IProgress<IReadOnlyList<FileSystemItem>> partialProgress = new Progress<IReadOnlyList<FileSystemItem>>(batch =>
            {
                if (!showPartial ||
                    !load.IsCurrent ||
                    token.IsCancellationRequested ||
                    !path.Equals(CurrentPath, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }

                SetDirectoryItems(batch);
                Layout = ResolveLayout(path, batch);
                readyMilliseconds ??= navigationTimer.ElapsedMilliseconds;
                StatusText = $"Opening… {batch.Count:N0} items ready";
                TimingText = $"{readyMilliseconds} ms first view";

            });

            var items = await _navigationLoads.LoadDirectoryAsync(load, path,
                new FolderLoadOptions(showHidden, column, descending, gridFastPath, showPartial, foldersFirst), partialProgress);

            if (token.IsCancellationRequested)
                return;

            FolderSnapshotCache.Set(path, items);
            SetDirectoryItems(items);

            // NEW (folder types, step 3): Automatic looks at what the folder contains. When that changes
            // the answer (first visit to a folder of photos, say), apply the detected type's view now;
            // next time it is known before the folder opens.
            if (AutomaticFolderTypeDetector.LearnContents(path, items) && _folderType.IsAutomatic)
                ReapplyDetectedType(path);

            _ = RefreshFolderExtrasAsync(path); // NEW (folder types, step 2): Git status, project strip
            stopwatch.Stop();
            readyMilliseconds ??= stopwatch.ElapsedMilliseconds;

            Layout = ResolveLayout(path, items);

            StatusText = SearchCoordinator.DescribeBrowsing(path, items);

            UpdateSearchStatus();

            TimingText = readyMilliseconds < stopwatch.ElapsedMilliseconds
                ? $"{readyMilliseconds} ms open · {stopwatch.ElapsedMilliseconds} ms complete"
                : $"{stopwatch.ElapsedMilliseconds} ms";
        }
        catch (OperationCanceledException)
        {
        }
        catch (UnauthorizedAccessException)
        {
            if (!load.IsCurrent) return;
            SetDirectoryItems([]);
            AccessDeniedPath = path;

            StatusText = ElevationService.IsElevated
                ? "Windows refused this folder even with administrator rights"
                : "You don't have permission to view this folder";
        }
        catch (DirectoryNotFoundException)
        {
            if (!load.IsCurrent) return;
            SetDirectoryItems([]);
            // CHANGED (zip folders): the same line serves a folder that is no longer in a ZIP file.
            StatusText = ArchiveLocation.Is(path) ? "That folder is no longer in the ZIP file" : "That folder no longer exists";
        }
        catch (IOException exception)
        {
            if (!load.IsCurrent) return;
            SetDirectoryItems([]);
            StatusText = exception.Message;
        }
        finally
        {
            if (load.IsCurrent)
            {
                IsLoading = false;
                Commands.RefreshState();
            }
        }
    }

    // ------------------------------------------------------------------ NEW (zip folders)
    // A ZIP file opens in the list like a folder: double-click it, press Enter on it, or type its path.
    // The list then shows what is in it, folder by folder, without unpacking anything
    // (Services/ArchiveBrowser.cs reads the ZIP's table of contents; Services/ArchiveLocation.cs has the
    // address of a place inside one). Back, Forward, Up, the address bar's trail, tabs, sorting, the
    // search box (it filters the folder on screen) and both views work as in a folder.
    // The inside of a ZIP is read-only here: files can be opened, copied or dragged out, and extracted,
    // but nothing in it can be renamed, deleted, tagged or locked, and nothing can be pasted into it.
    // The list is not kept up to date by itself; Refresh (F5) reads the ZIP file again.

    /// <summary>The list is showing the inside of a ZIP file.</summary>
    public bool IsInArchive => ArchiveLocation.Is(CurrentPath);

    private async Task LoadArchiveAsync(string path, Stopwatch stopwatch, CancellationToken token)
    {
        var column = SortColumn;
        var descending = SortDescending;
        var foldersFirst = _sortedFoldersFirst = FoldersFirst;

        // A missing or unreadable ZIP file throws from here with words for the status line; LoadAsync shows them.
        IReadOnlyList<FileSystemItem> items = await Task.Run(() =>
        {
            var list = ArchiveBrowser.List(path, token);
            list.Sort(new ItemComparer(column, descending, foldersFirst));
            IconService.Populate(list);
            IconService.PopulateTypeNames(list);
            ScalableIconService.PopulateGridPlaceholders(list);
            return list;
        }, token);

        if (token.IsCancellationRequested)
            return;

        FolderSnapshotCache.Set(path, items);
        SetDirectoryItems(items);
        Layout = ResolveLayout(path, items);
        stopwatch.Stop();
        StatusText = SearchCoordinator.DescribeBrowsing(path, items);
        UpdateSearchStatus();
        TimingText = $"{stopwatch.ElapsedMilliseconds} ms";
    }

    private async Task LoadVirtualDrivesAsync(string path, Stopwatch stopwatch, CancellationToken token)
    {
        var networkOnly = path.Equals(NetworkPath, StringComparison.OrdinalIgnoreCase);
        var drives = await Task.Run(() => LocationCatalog.EnumerateDriveItems(networkOnly), token);

        if (token.IsCancellationRequested)
            return;

        IconService.Populate(drives);
        ScalableIconService.PopulateGridPlaceholders(drives);
        FolderSnapshotCache.Set(path, drives);
        SetDirectoryItems(drives);
        Layout = LayoutMode.Grid;
        stopwatch.Stop();

        var total = drives.Sum(drive => drive.DriveTotalSpace);
        var available = drives.Sum(drive => drive.DriveAvailableSpace);

        StatusText = SearchCoordinator.DescribeBrowsing(networkOnly ? NetworkPath : MyPcPath, drives);
        UpdateSearchStatus();
        SetHubInfo(
            networkOnly ? "Network" : "This PC",
            drives.Count == 0
                ? networkOnly ? "No mapped locations" : "No local drives found"
                : $"{FileSystemItem.FormatSize(available)} available of {FileSystemItem.FormatSize(total)} total",
            networkOnly
                ? "Mapped network locations available to this computer. Select one to browse it."
                : $"{drives.Count:N0} local drive{(drives.Count == 1 ? string.Empty : "s")} · storage bars show the used space for each drive.");
        TimingText = $"{stopwatch.ElapsedMilliseconds} ms";
    }

    private async Task LoadHubAsync(string path, Stopwatch stopwatch, CancellationToken token)
    {
        var isPinnedHub = path.Equals(PinnedPath, StringComparison.OrdinalIgnoreCase);
        var isCloudHub = path.Equals(CloudPath, StringComparison.OrdinalIgnoreCase);
        var categoryId = path.StartsWith(CategoryPathPrefix, StringComparison.OrdinalIgnoreCase)
            ? path[CategoryPathPrefix.Length..]
            : null;

        // NEW (your files): a folder of yours that was deleted (here or anywhere else) comes off the list.
        if (path.Equals(YourFilesPath, StringComparison.OrdinalIgnoreCase))
            SidebarState.PruneLibraryFolders();

        var items = await Task.Run(() => LocationCatalog.BuildHubItems(isPinnedHub, isCloudHub, categoryId), token);

        if (token.IsCancellationRequested)
            return;

        IconService.Populate(items);
        ScalableIconService.PopulateGridPlaceholders(items);
        FolderSnapshotCache.Set(path, items);
        SetDirectoryItems(items);
        Layout = LayoutMode.Grid;
        stopwatch.Stop();
        StatusText = SearchCoordinator.DescribeBrowsing(path, items);
        UpdateSearchStatus();

        if (isCloudHub)
        {
            SetHubInfo(
                "Cloud",
                items.Count == 0
                    ? "No sync folders"
                    : $"{items.Count:N0} sync folder{(items.Count == 1 ? string.Empty : "s")}",
                "Folders a provider keeps in step with the cloud. Inside them the Status column shows what is actually stored on this device.");
            TimingText = $"{stopwatch.ElapsedMilliseconds} ms";
            return;
        }

        var categoryName = categoryId is null ? null : SettingsService.GetSidebarSections()
            .FirstOrDefault(section => section.Id.Equals($"category:{categoryId}", StringComparison.OrdinalIgnoreCase))?.Name;
        SetHubInfo(
            categoryName ?? (isPinnedHub ? "Favorites" : "Your files"),
            categoryName is not null
                ? items.Count == 0 ? "No items in this category" : $"{items.Count:N0} saved location{(items.Count == 1 ? string.Empty : "s")}" 
                : isPinnedHub
                ? items.Count == 0 ? "Nothing pinned yet" : $"{items.Count:N0} saved location{(items.Count == 1 ? string.Empty : "s")}" 
                : items.Count > 6 ? $"{items.Count:N0} folders" : "Six primary folders", // CHANGED (your files): counts the ones you added
            categoryName is not null
                ? "Drag Favorites into or out of this category to keep your sidebar organized."
                : isPinnedHub
                ? "Pin any file or folder from its right-click menu to keep it within reach."
                // CHANGED (your files): says how to add your own.
                : "Desktop, Documents, Downloads, Pictures, Music, and Videos—your everyday starting points. Right-click an empty area to add a folder of your own.");
        TimingText = $"{stopwatch.ElapsedMilliseconds} ms";
    }

    private void SetHubInfo(string title, string summary, string description)
    {
        HubTitle = title;
        HubSummary = summary;
        HubDescription = description;
        OnPropertyChanged(nameof(IsHub));
    }

    private void ClearHubInfo()
    {
        if (!IsHub)
            return;

        HubTitle = string.Empty;
        HubSummary = string.Empty;
        HubDescription = string.Empty;
        OnPropertyChanged(nameof(IsHub));
    }

    private static LayoutMode ResolveLayout(string path, IReadOnlyList<FileSystemItem> items)
    {
        // CHANGED (folder types): the type in effect (own or inherited) decides, when it has a layout.
        if (FolderTypes.Effective(path) is { IsAutomatic: false, Layout: { } typed })
        {
            if (typed == LayoutMode.Grid && items.Count <= GridItemLimit)
                return LayoutMode.Grid;
            if (typed == LayoutMode.Details)
                return LayoutMode.Details;
        }

        var saved = SettingsService.GetFolderLayout(path);

        if (saved is not null && Enum.TryParse<LayoutMode>(saved, out var chosen))
        {
            if (chosen == LayoutMode.Grid && items.Count > GridItemLimit)
                return LayoutMode.Details;

            return chosen;
        }

        if (items.Count <= GridItemLimit &&
            (KnownFolders.IsWithinPictures(path) ||
             MediaTypes.LooksVisual(items) ||
             FolderTypes.Detected(path, lookAtContents: true).Layout == LayoutMode.Grid)) // CHANGED (step 3): detected type incl. contents
            return LayoutMode.Grid;

        return LayoutMode.Details;
    }

    private void RestoreFolderProfile(string path)
    {
        // CHANGED (folder types): own type, else inherited from a parent, else Automatic.
        var type = FolderTypes.Effective(path, out var inheritedFrom);
        ApplyFolderType(type, inheritedFrom);
        OnPropertyChanged(nameof(CanSetFolderProfile));
    }

    private void UpdateStatus()
    {
        var selected = Context.SelectedItems;

        if (selected.Count == 0)
            return;

        if (selected.Count == 1)
        {
            var item = selected[0];
            StatusText = item.IsFolder
                ? $"{item.Name}  ·  folder"
                : $"{item.Name}  ·  {item.SizeText}";
            return;
        }

        var total = selected.Where(item => !item.IsFolder).Sum(item => item.Size);
        StatusText = $"{selected.Count:N0} selected  ·  {FileSystemItem.FormatSize(total)}";
    }

    private async Task EnsureItemIconsAsync()
    {
        var missing = Items.Where(item => item.Icon is null).ToArray();
        if (missing.Length == 0)
            return;

        var resolved = await Task.Run(() => missing
            .Select(item => (Icon: IconService.GetIcon(item), TypeName: IconService.GetTypeName(item)))
            .ToArray());
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is null)
            return;

        await dispatcher.InvokeAsync(() =>
        {
            for (var index = 0; index < missing.Length; index++)
            {
                missing[index].Icon = resolved[index].Icon;
                missing[index].TypeName = resolved[index].TypeName;
            }
        });
    }

    private static IReadOnlyList<Breadcrumb> BuildBreadcrumbs(string path)
        => NavigationBreadcrumbs.BuildBreadcrumbs(path, id => SettingsService.GetSidebarSections()
            .FirstOrDefault(section => section.Id.Equals($"category:{id}", StringComparison.OrdinalIgnoreCase))?.Name);

    public void Dispose()
    {
        _liveFolderClosed = true;    // NEW (live folder)
        _folderWatcher.Dispose();
        _mergeCancel?.Cancel();
        _search.Dispose();
        _navigationLoads.Dispose();
        _fileOperationTimer?.Stop(); // NEW (status line)
        Player.Stop();            // NEW (new window): a closed window must not keep playing while others stay open
        SidebarState.Dispose();   // NEW (new window): this window's sidebar stops following settings changes
        _extrasCancel?.Cancel(); // NEW (folder types, step 2)
        FileIndexService.Changed -= OnFileIndexChanged;
        TagService.Changed -= OnTagsChanged;
    }

    private void OnTagsChanged(object? sender, EventArgs e)
    {
        RefreshTagOptions();
        if (HasSearch) ApplySearchFilter(updateStatus: false);
    }

    public void SetSidebarLocation(string name, string path) => SidebarState.SetSidebarLocation(name, path);
    public void ResetSidebarLocation(string name) => SidebarState.ResetSidebarLocation(name);
    public void PinDirectory(string path) => SidebarState.PinDirectory(path);
    public void UnpinDirectory(string path) => SidebarState.UnpinDirectory(path);
    public void CreatePinnedCategory(string name) => SidebarState.CreatePinnedCategory(name);
    public void RenamePinnedCategory(string id, string name) => SidebarState.RenamePinnedCategory(id, name);
    public void DeletePinnedCategory(string id) => SidebarState.DeletePinnedCategory(id);
    public void TogglePinnedCategory(string id) => SidebarState.TogglePinnedCategory(id);
    public void ToggleSidebarSection(string id) => SidebarState.ToggleSidebarSection(id);
    public void RenameSidebarSection(string id, string name) => SidebarState.RenameSidebarSection(id, name);
    public void MoveSidebarSection(string sourceId, string targetId, bool placeAfter) => SidebarState.MoveSidebarSection(sourceId, targetId, placeAfter);
    public void MovePinnedDirectory(string path, string? categoryId, string? targetPath, bool placeAfter) => SidebarState.MovePinnedDirectory(path, categoryId, targetPath, placeAfter);
    public void MovePinnedCategory(string sourceId, string beforeId) => SidebarState.MovePinnedCategory(sourceId, beforeId);
}
